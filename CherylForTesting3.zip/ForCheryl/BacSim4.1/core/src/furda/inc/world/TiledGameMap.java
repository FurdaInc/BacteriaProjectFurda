package furda.inc.world;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.*;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer.Cell;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector3;
import furda.inc.entities.*;

import java.util.concurrent.ThreadLocalRandom;


public class TiledGameMap extends GameMap {

    TiledMap tiledMap;
    OrthogonalTiledMapRenderer tiledMapRenderer;
    OrthographicCamera camera;


    //Spawn areas and parameters for the bacteria.
    //Ensures that the bacteria do not spawn on top of eachother
    final int spawnWidthL, spawnWidthR, spawnHeightL, spawnHeightR;
    int[] xSpawn;
    int[] ySpawn;
    int spawnCount;


    //Bacteria info to be stored in the following structs
    BacteriaInfo redBacteriaInfo, blueBacteriaInfo;


    //Some booleans that denote which game mode we are using
    private boolean gameMode1; // Only blue bacteria available
    private boolean gameMode2; // Blue bacteria and one blocker
    private boolean gameMode3; // Blue bacteria both blockers and WBC
    private boolean gameMode4;
    private boolean modeSelected;
    private boolean restartTrigger;


    //Some booleans to denote which of the entities is going to be updated on a given rotation (stops concurrent mod issues)
    private boolean updateBlue = false;
    private boolean updateRed = false;
    private boolean updateGarlic = false;
    private boolean updateAntiBiotics = false;
    private boolean updateWBC = false;

    //Booleans for the final spawns
    private boolean blueComplete;
    private boolean redComplete;
    int bacCompleteCount;
    int inPosition;

    private int removalIndex;


    //For the red enzyme spawning
    private boolean redSpawnEnzyme;
    BacteriaRed tempRedParent;



    //TESTING MEMORY USAGE HERE
    Runtime rt = Runtime.getRuntime();
    long prevTotal = 0;
    long prevFree = rt.freeMemory();
    int i = 0;
    //TESTING MEMORY SETUP ENDS


    public TiledGameMap(OrthographicCamera set) {

        //Reading map from the assets folder
        //tiledMap = new TmxMapLoader().load("FinalMap.tmx");
        tiledMap = new TmxMapLoader().load("BacMap5.tmx");
        tiledMapRenderer = new OrthogonalTiledMapRenderer(tiledMap);
        camera = set;
        gameMode1 = false;
        gameMode2 = false;
        gameMode3 = false;
        gameMode4 = false;
        modeSelected = false;
        restartTrigger = false;

        blueComplete = false;
        redComplete = false;
        BacteriaFinal.finalSpawned = false;
        redSpawnEnzyme = false;

        //Setting the initial counts for the number of red and blue bacteria
        BacteriaBlue.setBlueCount(0);
        BacteriaRed.setRedCount(0);

        //Setting removal index to -1
        removalIndex = -1;


        //Settings the spawn dimensions and areas within the constructor
        spawnWidthL = 32;
        spawnWidthR = ((getWidth()-10) * 16);
        spawnHeightL = 32;
        spawnHeightR = ((getHeight()-10) * 16);
        xSpawn = new int[32];
        ySpawn = new int[32];
        populateSpawns();
        spawnCount = 1;

        //System.out.println("Height: " + getHeight());
        //System.out.println("Width : " + getWidth());


        entities.add(new Button(290, 350,this,new Texture("TempTitleButton1.png"), EntityType.BUTTON, 1));
        entities.add(new Button(290, 250,this,new Texture("TempTitleButton2.png"), EntityType.BUTTON, 2));
        entities.add(new Button(290, 150,this,new Texture("TempTitleButton3.png"), EntityType.BUTTON, 3));
        entities.add(new Button(290, 50,this,new Texture("TempTitleButton4.png"), EntityType.BUTTON, 4));


        entities.add(new Button(650,30,this,new Texture("TempQuit.png"),0));
        entities.add(new Button(650,130,this,new Texture("TempRestart.png"),1));





        //entities.add(new Button(30,30,this, new Texture("TempBlueSpawn.png"), EntityType.BACTERIABLUE));
        //entities.add(new Button(160,30,this, new Texture("TempRedSpawn.png"), EntityType.BACTERIARED));
        //entities.add(new Button(290,30,this, new Texture("TempWBCSpawn.png"), EntityType.WBC));
        //entities.add(new Button(420,30,this, new Texture("TempGarlicSpawn.png"), EntityType.GARLIC));
        //entities.add(new Button(550,30,this, new Texture("TempAntibioticSpawn.png"), EntityType.ANTIBIOTIC));


        blueBacteriaInfo = new BacteriaInfo(EntityType.BACTERIABLUE);
        redBacteriaInfo = new BacteriaInfo(EntityType.BACTERIARED);

        //entities.add(new Garlic(ThreadLocalRandom.current().nextInt(spawnWidthL, spawnWidthR), ThreadLocalRandom.current().nextInt(spawnHeightL, spawnHeightR), EntityType.GARLIC, this));

        //Spore deletion test
        //Spore.sporeCount = 1;

    }

    @Override
    public void render(OrthographicCamera camera, SpriteBatch batch) {
        tiledMapRenderer.setView(camera);
        tiledMapRenderer.render();

        //The below makes a call to the parent classes method 'render' (GameMap)
        //This is where I'll be adding my code later
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        super.render(camera, batch);

        batch.end();
    }

    @Override
    public void update(float delta){


        /*//FOR TESTING
        float x = getMousePosInMap(this.returnCam()).x;
        float y = getMousePosInMap(this.returnCam()).y;
        if (Gdx.input.justTouched()) {
            System.out.println("Mouse x pos: " + x);
            System.out.println("Mouse y pos: " + y);
        }
        //TEST AREA ENDS*/

        /*//TESTING MEMORY HERE
        long total = rt.totalMemory();
        long free = rt.freeMemory();
        if (total != prevTotal || free != prevFree) {
            System.out.println("Currently " + entities.size() + " items in entities.");
            System.out.println(
                    String.format("Loop: %s, \tTotal: %s, \tFree: %s, \tDiff: %s",
                            i,
                            total/1024,
                            free/1024,
                            (prevFree - free)/1024));
            prevTotal = total;
            prevFree = free;
        }
        i+=1;
        //MEMORY TESTING ENDS*/

        //CHecking for restart here
        if(restartTrigger){
            restartSim();
        }

        //Initialising the game mode here
        if(gameMode1){
            entities.add(new Button(30,30,this, new Texture("TempBlueSpawn.png"), EntityType.BACTERIABLUE));
            gameMode1 = false;
            modeSelected = true;
        }
        if(gameMode2){
            entities.add(new Button(30,30,this, new Texture("TempBlueSpawn.png"), EntityType.BACTERIABLUE));
            entities.add(new Button(550,30,this, new Texture("TempAntibioticSpawn.png"), EntityType.ANTIBIOTIC));
            gameMode2 = false;
            modeSelected = true;
        }
        if(gameMode3){
            entities.add(new Button(30,30,this, new Texture("TempBlueSpawn.png"), EntityType.BACTERIABLUE));
            entities.add(new Button(290,30,this, new Texture("TempWBCSpawn.png"), EntityType.WBC));
            entities.add(new Button(420,30,this, new Texture("TempGarlicSpawn.png"), EntityType.GARLIC));
            entities.add(new Button(550,30,this, new Texture("TempAntibioticSpawn.png"), EntityType.ANTIBIOTIC));
            gameMode3 = false;
            modeSelected = true;
        }
        if(gameMode4){
            entities.add(new Button(30,30,this, new Texture("TempBlueSpawn.png"), EntityType.BACTERIABLUE));
            entities.add(new Button(160,30,this, new Texture("TempRedSpawn.png"), EntityType.BACTERIARED));
            gameMode4 = false;
            modeSelected = true;
        }



        //THIS IS MAKING IT RUN SLOW
        bacCompleteCount = 0;
        inPosition = 0;
        for (BacteriaGeneral bac : blueBacteriaInfo.getBacteriaArray()){

            if (bac == null){
                //System.out.println("No blue spawned");
                break;
            }
            if(!bac.getAllBound()){
                //System.out.println(bac.getID() + "Not fully bound.");
                break;
            }
            bacCompleteCount+=1;
            if (bacCompleteCount == 4) {
                //System.out.println("If we got to here, all bac are fully bound.");
                BacteriaBlue.setBlueComplete();
            }
            //System.out.println("?????");
            if(bac.getInPlace()){
                //System.out.println(bac.getID() + " in position for merge.");
                inPosition+=1;
            }
            if(inPosition == 4){
                //System.out.println("Winner!");
                blueComplete = true;
            }

        }

        bacCompleteCount = 0;
        inPosition = 0;
        for (BacteriaGeneral bac : redBacteriaInfo.getBacteriaArray()){

            if (bac == null){
                //System.out.println("No blue spawned");
                break;
            }
            if(!bac.getAllBound()){
                //System.out.println(bac.getID() + "Not fully bound.");
                break;
            }
            bacCompleteCount+=1;
            if (bacCompleteCount == 4) {
                //System.out.println("If we got to here, all bac are fully bound.");
                BacteriaRed.setRedComplete();
            }
            //System.out.println("?????");
            if(bac.getInPlace()){
                //System.out.println("Bacteria in position.");
                inPosition+=1;
            }
            if(inPosition == 4){
                //System.out.println("All bacteria in position.");
                redComplete = true;
            }

        }




        if (updateBlue) {
            if (blueBacteriaInfo.getBacteriaCount() > 3) {
                updateBlue = false;
                return;
            }
            addEntity(EntityType.BACTERIABLUE);
            BacteriaBlue.getInfo(blueBacteriaInfo);
            BacteriaRed.getCompetingInfo(blueBacteriaInfo);

        }
        if (updateRed) {
            if (redBacteriaInfo.getBacteriaCount() > 3) {
                updateRed = false;
                return;
            }
            addEntity(EntityType.BACTERIARED);
            BacteriaRed.getInfo(redBacteriaInfo);
        }
        if (updateGarlic)
            addEntity(EntityType.GARLIC);
        if (updateAntiBiotics)
            addEntity(EntityType.ANTIBIOTIC);
        if (updateWBC)
            addEntity(EntityType.WBC);
        if (redSpawnEnzyme){
            spawnRedEnzyme(tempRedParent);
        }


        for(Entity entity : entities){
            //entity.update(delta, -9.8f);
            //Mode selection, this removes the menu buttons after a mode is selected
            if(modeSelected){
                if(entity.getType() == EntityType.BUTTON){
                    if(entity.getGameMode()!=-1){
                        entity.setToRemove(true);
                    }
                }
            }
            if((redComplete || blueComplete) && entity.getType() != EntityType.BACTERIAFINAL){
                entity.setToRemove(true);
            }

            //Removal for all other entities after blue completion
            if(BacteriaBlue.getBlueComplete() && entity.getType()!=EntityType.BACTERIABLUE && entity.getRemovable()){
                entity.setToRemove(true);
            }

            for(BacteriaGeneral bac : blueBacteriaInfo.getBacteriaArray()){

                if(entity.getType() == EntityType.BACTERIARED)
                    break;
                if (entity.getType() == EntityType.ANTIBIOTIC || entity.getType() == EntityType.GARLIC){
                    if (bac == null){
                        //System.out.println("No blue spawned");
                        break;
                    }
                    if(bac.checkBinding(entity.getX(),entity.getY(),entity.getType())){
                        bac.setBlockerBound(entity.getType());
                        entity.setToRemove(true);
                        removalIndex = entities.indexOf(entity);

                    }
                }
                if(entity.getType() == EntityType.REDENZYME) {
                    if (bac == null) {
                        //System.out.println("No blue spawned");
                        break;
                    }
                    if (bac.checkBinding(entity.getX(), entity.getY(), entity.getType())) {
                        bac.setBlockerBound(entity.getType());
                        entity.setToRemove(true);
                        removalIndex = entities.indexOf(entity);
                    }
                }
                if(entity.getType() == EntityType.WBC){
                    if (bac == null){
                        //System.out.println("No blue spawned");
                        break;
                    }
                    if(bac.checkBinding(entity.getX(),entity.getY(),entity.getType())) {
                        removalIndex = entities.indexOf(entity);
                        blueBacteriaInfo.setBacteriaToRemove(bac);
                        entity.setToRemove(true);
                        //System.out.println("Bacteria set to remove.");
                    }
                }
                if(entity.getType() == EntityType.BACTERIABLUE) {
                    if (blueBacteriaInfo.getBacteriaToRemove() != null) {
                        if (entity.getID() == blueBacteriaInfo.getBacteriaToRemove().getID()) {
                            removalIndex = entities.indexOf(entity);
                            blueBacteriaInfo.getBacteriaToRemove().setRemoved();
                        }
                    }
                    break;
                }
            }
            if (entity.getToRemove()){
                //System.out.println("Removing entity: " + entity.getType().getId());
                removalIndex = entities.indexOf(entity);
            }
            //if(entity.getType() == EntityType.)
            entity.update(delta, 0);
        }
        if(removalIndex != -1) {
            entities.remove(removalIndex);
            removalIndex = -1;
        }
        if(removalIndex != -1){
            entities.remove(removalIndex);
            blueBacteriaInfo.setBacteriaToRemove(null);
            removalIndex = -1;

        }
        if(blueComplete && !BacteriaFinal.finalSpawned){
            entities.add(new BacteriaFinal(((this.getWidth()/2*16)/6)*2, this.getHeight()/2*16, EntityType.BACTERIABLUE, this));
            BacteriaFinal.finalSpawned = true;
        }
        if(redComplete && !BacteriaFinal.finalSpawned){
            entities.add(new BacteriaFinal(((this.getWidth()/2*16)/6)*2, this.getHeight()/2*16, EntityType.BACTERIARED, this));
            BacteriaFinal.finalSpawned = true;
        }

    }

    @Override
    public void dispose() {
        tiledMap.dispose();

    }

    @Override
    public TileType getTileTypeByCoordinate(int layer, int col, int row) {

        Cell cell = ((TiledMapTileLayer) tiledMap.getLayers().get(layer)).getCell(col, row);

        if(cell!=null){
            TiledMapTile tile = cell.getTile();
            if (tile!=null){
                int id = tile.getId();
                return TileType.getTileTypeById(id);
            }
            //If the cell is null we are either clicking outside the map or it does not exist on the layer we are exploring
        }

        return null;
    }


    @Override
    public void setUpdate(EntityType e) {
        if (e == EntityType.BACTERIABLUE)
            updateBlue = true;
        else if (e == EntityType.BACTERIARED)
            updateRed = true;
        else if (e == EntityType.WBC)
            updateWBC = true;
        else if (e == EntityType.ANTIBIOTIC)
            updateAntiBiotics = true;
        else if (e == EntityType.GARLIC)
            updateGarlic = true;
        else
            return;
    }

    @Override
    public void addEntity(EntityType e) {
        if (e == EntityType.BACTERIABLUE) {
            blueBacteriaInfo.setBacteriaToAlter(new BacteriaBlue(xSpawn[spawnCount], ySpawn[spawnCount], this));
            blueBacteriaInfo.setBacteriaArray(blueBacteriaInfo.getBacteriaToAlter().getID(), blueBacteriaInfo.getBacteriaToAlter());
            blueBacteriaInfo.incrementBacteriaCount();
            spawnCount+=1;
            entities.add(blueBacteriaInfo.getBacteriaToAlter());
            updateBlue = false;
            blueBacteriaInfo.setBacteriaToAlter(null);
        }
        else if (e == EntityType.BACTERIARED) {
            redBacteriaInfo.setBacteriaToAlter(new BacteriaRed(xSpawn[spawnCount], ySpawn[spawnCount], this));
            redBacteriaInfo.setBacteriaArray(redBacteriaInfo.getBacteriaToAlter().getID(), redBacteriaInfo.getBacteriaToAlter());
            redBacteriaInfo.incrementBacteriaCount();
            spawnCount+=1;
            entities.add(redBacteriaInfo.getBacteriaToAlter());
            updateRed = false;
            redBacteriaInfo.setBacteriaToAlter(null);
        }
        else if (e == EntityType.WBC) {
            updateWBC = false;
            entities.add(new WBC(ThreadLocalRandom.current().nextInt(spawnWidthL, spawnWidthR), ThreadLocalRandom.current().nextInt(spawnHeightL, spawnHeightR), EntityType.WBC, this));
        }else if (e == EntityType.ANTIBIOTIC) {
            entities.add(new Antibiotic(ThreadLocalRandom.current().nextInt(spawnWidthL, spawnWidthR), ThreadLocalRandom.current().nextInt(spawnHeightL, spawnHeightR), EntityType.ANTIBIOTIC, this));
            updateAntiBiotics = false;
        }else if (e == EntityType.GARLIC){
            entities.add(new Garlic(ThreadLocalRandom.current().nextInt(spawnWidthL, spawnWidthR), ThreadLocalRandom.current().nextInt(spawnHeightL, spawnHeightR), EntityType.GARLIC, this));
            updateGarlic = false;
        }else
            return;
    }

    @Override
    public void addEntity(EntityType e, BacteriaGeneral parent){
        System.out.println("Big johnny two hats");
        return;
    }

    public OrthographicCamera returnCam(){
        return camera;
    }

    public void populateSpawns() {
        boolean checkSpace;
        for (int j = 1; j < 12; j++) {
            checkSpace = false;
            xSpawn[j] = ThreadLocalRandom.current().nextInt(spawnWidthL, spawnWidthR);
            ySpawn[j] = ThreadLocalRandom.current().nextInt(spawnHeightL, spawnHeightR);
            while (checkSpace == false) {
                checkSpace = true;
                if (xSpawn[j] < 668 && ySpawn[j] < 95){
                    checkSpace = false;
                    xSpawn[j] = ThreadLocalRandom.current().nextInt(spawnWidthL, spawnWidthR);
                    ySpawn[j] = ThreadLocalRandom.current().nextInt(spawnHeightL, spawnHeightR);
                }else {
                    for (int i = 0; i < j; i++) {
                        while ((xSpawn[j] > xSpawn[i] - 128 && xSpawn[j] < xSpawn[i] + 128) && (ySpawn[j] > ySpawn[i] - 64 && ySpawn[j] < ySpawn[i] + 64)) {
                            checkSpace = false;
                            xSpawn[j] = ThreadLocalRandom.current().nextInt(spawnWidthL, spawnWidthR);
                            ySpawn[j] = ThreadLocalRandom.current().nextInt(spawnHeightL, spawnHeightR);
                        }

                    }
                }
            }
            //System.out.println("Spawn " + j);
            //System.out.println("x: " + xSpawn[j]);
            //System.out.println("y: " + ySpawn[j]);
        }
    }


    @Override
    public int getWidth() {
        return ((TiledMapTileLayer) tiledMap.getLayers().get(0)).getWidth();
    }

    @Override
    public int getHeight() {
        return ((TiledMapTileLayer) tiledMap.getLayers().get(0)).getHeight();
    }

    @Override
    public int getLayers() {
        return tiledMap.getLayers().getCount();
    }

    public Vector3 getMousePosInMap(OrthographicCamera cam){
        return cam.unproject(new Vector3(Gdx.input.getX(), Gdx.input.getY(),0));
    }

    @Override
    public void setMode(int gameMode){
        if(gameMode == 1) {
            gameMode1 = true;
        }else if (gameMode == 2){
            gameMode2 = true;
        }else if (gameMode == 3){
            gameMode3 = true;
        }else if (gameMode == 4){
            gameMode4 = true;
        }
    }

    @Override
    public void triggerRestart(){
        restartTrigger = true;
    }

    @Override
    public void restartSim(){
        entities.clear();

        gameMode1 = false;
        gameMode2 = false;
        gameMode3 = false;
        gameMode4 = false;
        modeSelected = false;
        blueComplete = false;
        redComplete = false;
        BacteriaFinal.finalSpawned = false;
        redSpawnEnzyme = false;

        populateSpawns();
        spawnCount = 1;

        BacteriaBlue.setBlueNotComplete();

        //Setting the initial counts for the number of red and blue bacteria
        BacteriaBlue.setBlueCount(0);
        BacteriaRed.setRedCount(0);

        //Setting removal index to -1
        removalIndex = -1;

        entities.add(new Button(290, 350,this,new Texture("TempTitleButton1.png"), EntityType.BUTTON, 1));
        entities.add(new Button(290, 250,this,new Texture("TempTitleButton2.png"), EntityType.BUTTON, 2));
        entities.add(new Button(290, 150,this,new Texture("TempTitleButton3.png"), EntityType.BUTTON, 3));
        entities.add(new Button(290, 50,this,new Texture("TempTitleButton4.png"), EntityType.BUTTON, 4));


        entities.add(new Button(650,30,this,new Texture("TempQuit.png"),0));
        entities.add(new Button(650,130,this,new Texture("TempRestart.png"),1));


        blueBacteriaInfo = new BacteriaInfo(EntityType.BACTERIABLUE);
        redBacteriaInfo = new BacteriaInfo(EntityType.BACTERIARED);

        restartTrigger = false;
    }


    public void triggerSpawn(BacteriaRed parent){
        redSpawnEnzyme = true;
        tempRedParent = parent;
    }
    @Override
    public void spawnRedEnzyme(BacteriaRed parent){
        entities.add(new RedEnzyme(EntityType.REDENZYME, this, parent));
        redSpawnEnzyme = false;
        tempRedParent = null;
    }






}
