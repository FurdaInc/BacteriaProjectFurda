package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;

public class Garlic extends Particles {

    //Animation test
    private TextureRegion[] regions = new TextureRegion[7];
    private int roll;
    private int count;

    public Garlic(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        image = new Texture("Garlic.png");
        regions[0] = new TextureRegion(image, 0, 0, 11,13);
        regions[1] = new TextureRegion(image, 0, 0, 11,13);
        regions[2] = new TextureRegion(image, 11, 0, 11,13);
        regions[3] = new TextureRegion(image, 11, 0, 11,13);
        regions[4] = new TextureRegion(image, 0, 13, 11,13);
        regions[5] = new TextureRegion(image, 0, 13, 11,13);
        regions[6] = new TextureRegion(image, 11, 13, 11,13);
    }

    @Override
    public void render(SpriteBatch batch) {

        if (roll == 7){
            roll = 0;
        }
        //System.out.println("I get called");
        /*for(int i = 0; i <regions.length; i++){
            batch.draw(regions[i], pos.x, pos.y, getWidth(), getHeight());
        }*/
        batch.draw(regions[roll], pos.x, pos.y, getWidth(), getHeight());
        //super.render(batch);
        count +=1;
        if (count == 10) {
            roll += 1;
            count = 0;
        }
        //Here is replication (or maybe original?)

    }


}
