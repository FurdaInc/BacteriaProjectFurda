package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

public class BacteriaRed extends BacteriaGeneral {

    static int redCount;

    static BacteriaInfo otherRed;
    static BacteriaInfo competingBlue;
    static boolean redComplete;

    private boolean spawnedEnzyme;


    public BacteriaRed(float x, float y, GameMap map) {
        super(x, y, EntityType.BACTERIARED, map);
        redComplete = false;
        spawnedEnzyme = false;

        setID(redCount);
        redCount += 1;

        //THIS IS FOR TESTING
        image = new Texture("RedBacTemp.jpg");
        System.out.println("Current red count: ");
        System.out.println(redCount);

        //TESTING END

    }

    @Override
    public void update(float deltaTime, float gravity) {
        super.update(deltaTime, gravity);
        //System.out.println(getID() + " Currently has: " + getSporeCount());
        if(getRedComplete()){
            if(Math.floor(getY())>((map.getHeight()*16)/2)){
                moveY(-getSpeed()*deltaTime);
                //System.out.println("My y is: " + getY());
                //System.out.println("Moving too: " + (map.getHeight()*16)/2);
            }
            else if(Math.ceil(getY())<((map.getHeight()*16)/2)){
                moveY(getSpeed()*deltaTime);
                //System.out.println("My y is: " + getY());
                //System.out.println("Moving too: " + (map.getHeight()*16)/2);
            }else{
                //System.out.println("CHUR");
                setInPlaceY();
            }
            if(Math.floor(getX()) > (((map.getWidth())*16)/6)*(getID()+1)){
                moveX(-getSpeed()*deltaTime);
            }
            else if(Math.ceil(getX()) < (((map.getWidth())*16)/6)*(getID()+1)){
                moveX(getSpeed()*deltaTime);
            }else{
                //System.out.println("Skeet skeet");
                setInPlaceX();
            }

        }

        for (BacteriaGeneral red : otherRed.getBacteriaArray()) {
            if (red == null) {
                //This bacteria has not been spawned yet.
                //System.out.println("Ok this will work");
                continue;
            } else if (red.getID() == this.getID()) {
                //This red bacteria is myself, no interactions with self (or own spores) is needed.

                continue;
                //System.out.println("Hey that's me!" + blue.getID() + " " + this.getID());
                //System.out.println(blue.getPos().x);
                //System.out.println(this.getPos().x);
            } else {
                //Check through the spores of this bacteria to see if any are touching me
                //System.out.println("That ain't me." + blue.getID() + " " + this.getID());
                for (Spore bindableSpore : red.getMyspores()) {
                    if ((bindableSpore.pos.x >= this.pos.x && bindableSpore.pos.x <= this.posR.x) && (bindableSpore.pos.y >= this.pos.y && bindableSpore.pos.y <= this.posR.y)) {
                        if (checkBinding(bindableSpore.pos.x, bindableSpore.pos.y, EntityType.SPORE)) {

                            if (otherRed.getBacteriaToAlter() == null) {

                                otherRed.setTempSpore(bindableSpore);
                                otherRed.setBacteriaToAlter(red);
                            }
                        }
                    }
                }
            }
        }

        if(competingBlue != null && !spawnedEnzyme) {
            for (BacteriaGeneral blue : competingBlue.getBacteriaArray()) {
                if (blue == null) {
                    //This bacteria has not been spawned yet.
                    //System.out.println("Ok this will work");
                    continue;
                } else {
                    //Check through the spores of this bacteria to see if any are touching me
                    //System.out.println("That ain't me." + blue.getID() + " " + this.getID());
                    for (Spore bindableSpore : blue.getMyspores()) {
                        if ((bindableSpore.pos.x >= this.pos.x && bindableSpore.pos.x <= this.posR.x) && (bindableSpore.pos.y >= this.pos.y && bindableSpore.pos.y <= this.posR.y)) {
                            if (checkBinding(bindableSpore.pos.x, bindableSpore.pos.y, EntityType.REDENZYME)) {

                                if (competingBlue.getBacteriaToAlter() == null) {

                                    competingBlue.setTempSpore(bindableSpore);
                                    competingBlue.setBacteriaToAlter(blue);
                                    System.out.println("SCHNEL");
                                }
                            }
                        }
                    }

                }
            }
        }

        if(competingBlue != null) {
            if (competingBlue.getBacteriaToAlter() != null) {
                competingBlue.getBacteriaToAlter().getMyspores().remove(competingBlue.getTempSpore());
                competingBlue.setBacteriaToAlter(null);
                competingBlue.setTempSpore(null);
                map.triggerSpawn(this);
                spawnedEnzyme = true;
            }
        }


        if(otherRed.getBacteriaToAlter() != null){

            otherRed.getBacteriaToAlter().getMyspores().remove(otherRed.getTempSpore());
            otherRed.setBacteriaToAlter(null);
            otherRed.setTempSpore(null);
            //Spawns too many spores. Needs to be 4, (5 is good for testing)
            if (this.getSporeCount() < 5) {
                this.getMyspores().add(new Spore(this.getX(), this.getY(), EntityType.SPORE, map, this));
                this.setSporeCount(this.getSporeCount() + 1);
            }
        }



    }





    public static void setRedCount(int initialize) {
        redCount = initialize;
    }

    public static boolean getRedComplete(){
        return redComplete;
    }

    public static void setRedComplete(){
        redComplete = true;
    }

    @Override
    public int getBacteriaCount() {
        return redCount;
    }

    @Override
    public EntityType getBacteriaType() {
        return this.type;
    }

    public static void getInfo(BacteriaInfo bacteriaUpdate){
        otherRed = bacteriaUpdate;
    }

    public static void getCompetingInfo(BacteriaInfo bacteriaUpdate){
        competingBlue = bacteriaUpdate;
    }

}