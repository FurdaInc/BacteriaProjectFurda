package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

import java.util.ArrayList;

public class BacteriaBlue extends BacteriaGeneral {

    static int blueCount;

    static BacteriaInfo otherBlue;
    static boolean blueComplete;





    public BacteriaBlue(float x, float y, GameMap map) {
        super(x, y, EntityType.BACTERIABLUE, map);
        blueComplete = false;

        setID(blueCount);
        blueCount += 1;

        //THIS IS FOR TESTING
        image = new Texture("BlueBacTemp.jpg");
        System.out.println("Current blue count: ");
        System.out.println(blueCount);
        System.out.println("I am bacteria " + getID());
        System.out.println("My x1 pos is: " + pos.x);
        System.out.println("My y1 pos is: " + pos.y);
        System.out.println("My x2 pos is: " + posR.x);
        System.out.println("My y2 pos is: " + posR.y);
        //TESTING END

    }

    @Override
    public void update(float deltaTime, float gravity){
        super.update(deltaTime, gravity);

        if(getBlueComplete()){
            if(Math.floor(getY())>((map.getHeight()*16)/2)){
                moveY(-getSpeed()*deltaTime);
                //System.out.println("My y is: " + getY());
                //System.out.println("Moving too: " + (map.getHeight()*16)/2);
            }
            else if(Math.ceil(getY())<((map.getHeight()*16)/2)){
                moveY(getSpeed()*deltaTime);
                //System.out.println("My y is: " + getY());
                //System.out.println("Moving too: " + (map.getHeight()*16)/2);
            }else{
                //System.out.println("CHUR");
                setInPlaceY();
            }
            if(Math.floor(getX()) > (((map.getWidth())*16)/6)*(getID()+1)){
                moveX(-getSpeed()*deltaTime);
            }
            else if(Math.ceil(getX()) < (((map.getWidth())*16)/6)*(getID()+1)){
                moveX(getSpeed()*deltaTime);
            }else{
                //System.out.println("Skeet skeet");
                setInPlaceX();
            }
            /*if(getID() == 0){
                if(getY()>((map.getHeight()*16)/2)){
                    moveY(-getSpeed()*deltaTime);
                }
                else if(getY()<((map.getHeight()*16)/2)){
                    moveY(getSpeed()*deltaTime);
                }
                if(getX() > ((map.getWidth())*16)/6){
                    moveX(-getSpeed()*deltaTime);
                }
                else if(getX() < ((map.getWidth())*16)/6){
                    moveX(getSpeed()*deltaTime);
                }
            }
            if(getID() == 1){
                if(getY()>((map.getHeight()*16)/2)){
                    moveY(-getSpeed()*deltaTime);
                }
                else if(getY()<((map.getHeight()*16)/2)){
                    moveY(getSpeed()*deltaTime);
                }
                if(getX() > (((map.getWidth())*16)/6)*2){
                    moveX(-getSpeed()*deltaTime);
                }
                else if(getX() < (((map.getWidth())*16)/6)*2){
                    moveX(getSpeed()*deltaTime);
                }
            }
            if(getID() == 2){
                if(getY()>((map.getHeight()*16)/2)){
                    moveY(-getSpeed()*deltaTime);
                }
                else if(getY()<((map.getHeight()*16)/2)){
                    moveY(getSpeed()*deltaTime);
                }
                if(getX() > ((map.getWidth())*16)/6*3){
                    moveX(-getSpeed()*deltaTime);
                }
                else if(getX() < ((map.getWidth())*16)/6*3){
                    moveX(getSpeed()*deltaTime);
                }
            }
            if(getID() == 3){
                if(getY()>((map.getHeight()*16)/2)){
                    moveY(-getSpeed()*deltaTime);
                }
                else if(getY()<((map.getHeight()*16)/2)){
                    moveY(getSpeed()*deltaTime);
                }
                if(getX() > ((map.getWidth())*16)/6*4){
                    moveX(-getSpeed()*deltaTime);
                }
                else if(getX() < ((map.getWidth())*16)/6*4){
                    moveX(getSpeed()*deltaTime);
                }
            }*/
            //System.out.println("Victory?");
        }

        for (BacteriaGeneral blue : otherBlue.getBacteriaArray()) {
            if (blue == null) {
                //This bacteria has not been spawned yet.
                //System.out.println("Ok this will work");
                continue;
            } else if (blue.getID() == this.getID()) {
                //This blue bacteria is myself, no interactions with self (or own spores) is needed.

                continue;
                //System.out.println("Hey that's me!" + blue.getID() + " " + this.getID());
                //System.out.println(blue.getPos().x);
                //System.out.println(this.getPos().x);
            } else {
                //Check through the spores of this bacteria to see if any are touching me
                //System.out.println("That ain't me." + blue.getID() + " " + this.getID());
                for (Spore bindableSpore : blue.getMyspores()) {
                    if ((bindableSpore.pos.x >= this.pos.x && bindableSpore.pos.x <= this.posR.x) && (bindableSpore.pos.y >= this.pos.y && bindableSpore.pos.y <= this.posR.y)) {
                        if (checkBinding(bindableSpore.pos.x, bindableSpore.pos.y, EntityType.SPORE)) {

                            if (otherBlue.getBacteriaToAlter() == null) {

                                otherBlue.setTempSpore(bindableSpore);
                                otherBlue.setBacteriaToAlter(blue);
                            }
                            //otherBlue.getBacteriaToAlter().getMyspores().remove(otherBlue.getTempSpore());


                        }

                        //System.out.println("\n\n");
                        //System.out.println("We cookin" + blue.getID() + this.getID());
                        //System.out.println(blue.pos.x);
                        //System.out.println(this.pos.x);

                    }
                }

            }
        }

        if(otherBlue.getBacteriaToAlter() != null){

            otherBlue.getBacteriaToAlter().getMyspores().remove(otherBlue.getTempSpore());
            otherBlue.setBacteriaToAlter(null);
            otherBlue.setTempSpore(null);
            //Spawns too many spores. Needs to be 4, (5 is good for testing)
            if (this.getSporeCount() < 5) {
                this.getMyspores().add(new Spore(this.getX(), this.getY(), EntityType.SPORE, map, this));
                this.setSporeCount(this.getSporeCount() + 1);
            }
        }

        //for(Spore spore : getMyspores()){
        //    spore.update(deltaTime, gravity);
        //}

        //System.out.println(getID() + " spore count is: " + getSporeCount());

    }




    public static void setBlueCount(int initialize){
        blueCount = initialize;
    }

    public static boolean getBlueComplete(){
        return blueComplete;
    }

    public static void setBlueComplete(){
        blueComplete = true;
    }

    @Override
    public int getBacteriaCount() {
        return blueCount;
    }

    @Override
    public EntityType getBacteriaType() {
        return this.type;
    }

    @Override
    public void setBlockerBound(EntityType type) {
        super.setBlockerBound(type);
        if(type == EntityType.ANTIBIOTIC){
            image = new Texture("AntiBlockTemp.jpg");
        }
        if(type == EntityType.GARLIC){
            image = new Texture("GarlicBlockTemp.jpg");
        }
        if(type == EntityType.REDENZYME){
            image = new Texture("RedBlockTemp.jpg");
        }
    }

    public static void getInfo(BacteriaInfo bacteriaUpdate){
        otherBlue = bacteriaUpdate;
    }
}
