package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import furda.inc.world.GameMap;

public class WBC extends Particles{
    public WBC(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        image = new Texture("WBC.jpg");
    }
}
