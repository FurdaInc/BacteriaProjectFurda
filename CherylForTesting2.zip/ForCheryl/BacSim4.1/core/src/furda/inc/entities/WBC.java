package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;

public class WBC extends Particles{

    //Animation test
    private TextureRegion[] regionsR = new TextureRegion[9];
    private TextureRegion[] regionsL = new TextureRegion[9];
    Texture imageAlt;
    private int roll;
    private int count;

    public WBC(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        image = new Texture("WBCRight.png");
        regionsR[0] = new TextureRegion(image, 0, 0, 126,126);
        regionsR[1] = new TextureRegion(image, 126, 0, 126,126);
        regionsR[2] = new TextureRegion(image, 252, 0, 126,126);
        regionsR[3] = new TextureRegion(image, 0, 126, 126,126);
        regionsR[4] = new TextureRegion(image, 126, 126, 126,126);
        regionsR[5] = new TextureRegion(image, 252, 126, 126,126);
        regionsR[6] = new TextureRegion(image, 0, 252, 126,126);
        regionsR[7] = new TextureRegion(image, 126, 252, 126,126);
        regionsR[8] = new TextureRegion(image, 252, 252, 126,126);
        imageAlt = new Texture("WBCLeft.png");
        regionsL[0] = new TextureRegion(imageAlt, 0, 0, 126,126);
        regionsL[1] = new TextureRegion(imageAlt, 126, 0, 126,126);
        regionsL[2] = new TextureRegion(imageAlt, 252, 0, 126,126);
        regionsL[3] = new TextureRegion(imageAlt, 0, 126, 126,126);
        regionsL[4] = new TextureRegion(imageAlt, 126, 126, 126,126);
        regionsL[5] = new TextureRegion(imageAlt, 252, 126, 126,126);
        regionsL[6] = new TextureRegion(imageAlt, 0, 252, 126,126);
        regionsL[7] = new TextureRegion(imageAlt, 126, 252, 126,126);
        regionsL[8] = new TextureRegion(imageAlt, 252, 252, 126,126);
    }

    @Override
    public void render(SpriteBatch batch) {

        if (roll == 9){
            roll = 0;
        }
        /*for(int i = 0; i <regions.length; i++){
            batch.draw(regions[i], pos.x, pos.y, getWidth(), getHeight());
        }*/
        if(lastD2 == 4)
            batch.draw(regionsR[roll], pos.x, pos.y, getWidth(), getHeight());
        else
            batch.draw(regionsL[roll], pos.x, pos.y, getWidth(), getHeight());
        //super.render(batch);
        count +=1;
        if (count == 10) {
            roll += 1;
            count = 0;
        }
        //Here is replication (or maybe original?)

    }
}
