package furda.inc.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import furda.inc.world.GameMap;

public class Button extends Entity {

    Texture image;
    EntityType spawnType;
    Boolean quitButton;
    Boolean restartButton;


    public Button(float x, float y, GameMap map, Texture buttonType, EntityType spawnerType) {

        super(x, y, EntityType.BUTTON, map);
        image = buttonType;
        spawnType = spawnerType;
        quitButton = false;
        restartButton = false;
    }

    public Button(float x, float y,GameMap map, Texture buttonType, EntityType spawnerType, int gameMode) {
        super(x, y, EntityType.BUTTON, map);
        image = buttonType;
        spawnType = spawnerType;
        setGameMode(gameMode);
        quitButton = false;
        restartButton = false;
    }

    public Button(float x, float y,GameMap map, Texture buttonType, int quit){
        super(x, y, EntityType.BUTTON, map);
        image = buttonType;
        setRemovable(false);
        if(quit == 0) {
            quitButton = true;
            restartButton = false;
        }
        if(quit == 1){
            quitButton = false;
            restartButton = true;
        }
    }


    @Override
    public void update(float deltaTime, float gravity) {
        //super.update(deltaTime, gravity);
        mousePos = getMousePosInMap(map.returnCam());
        //int x = Gdx.input.getX() - 150;
        //int y = Gdx.input.getY() + 15;
        float x = mousePos.x;
        float y = mousePos.y;
        //if(this.clicked();)
        if ((x >= pos.x && x <= (pos.x + this.getWidth())) && (y >= pos.y && y <= (pos.y + this.getHeight()))) {
            if (Gdx.input.justTouched()) {
                if(quitButton == true){
                    Gdx.app.exit();
                }
                if(restartButton == true){
                    map.triggerRestart();
                }
                if(spawnType == EntityType.BUTTON){
                    map.setMode(getGameMode());
                }else {
                    map.setUpdate(spawnType);
                }
                /*if (spawnType == EntityType.BACTERIABLUE)
                    map.addEntity(type);
                if (spawnType == EntityType.BACTERIARED)
                    map.addEntity(type);
                if (spawnType == EntityType.WBC)
                    map.addEntity(type);
                if (spawnType == EntityType.ANTIBIOTIC)
                    map.addEntity(type);
                if (spawnType == EntityType.GARLIC)
                    map.addEntity(type);*/
            }
        }
        //System.out.println("Mouse pos: " + y);
        //System.out.println("Lower bound: " + pos.y);
        //System.out.println("Upper bound: " + (pos.y + this.getHeight()));
        //System.out.println(this.getWidth());


    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(image, pos.x, pos.y, getWidth(), getHeight());
    }

    public boolean checkBinding(float x, float y, EntityType type){
        return false;
    }


}
