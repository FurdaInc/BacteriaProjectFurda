package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import furda.inc.world.GameMap;

public class Spore extends Particles{

    private BacteriaGeneral myParent;

    public Spore(float x, float y, EntityType type, GameMap map, BacteriaGeneral parent) {
        super(x, y, type, map);
        myParent = parent;
        if (myParent.getBacteriaType() == EntityType.BACTERIABLUE){
            image = new Texture("PUT PATH HERE");
        }else{
            image = new Texture("PUT PATH HERE");
        }
    }

    boolean checkParent(BacteriaGeneral parent){
        if (myParent == parent){
            return  true;
        }
        return false;
    }

}
