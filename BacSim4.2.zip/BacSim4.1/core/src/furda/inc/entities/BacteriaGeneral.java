package furda.inc.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import furda.inc.world.GameMap;
import com.badlogic.gdx.graphics.g2d.Animation;

public abstract class BacteriaGeneral extends Entity {

    private Vector3 mousePos; // Position of the mouse, used for testing bindings

    Animation[] rolls; // The animation roll for movement of the bacteria
    private int roll; // The specific slide that the bacteria is on

    private int sporeCount;

    public BacteriaGeneral(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
    }


    public int getSporeCount(){ return sporeCount;}
    public abstract int getBacteriaCount();

    public abstract EntityType getBacteriaType();


}
