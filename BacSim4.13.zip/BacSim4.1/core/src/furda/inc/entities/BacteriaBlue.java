package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;

import java.util.ArrayList;

public class BacteriaBlue extends BacteriaGeneral {

    static int blueCount;

    static BacteriaInfo otherBlue;
    static boolean blueComplete;

    //Animation test
    private TextureRegion[] regions = new TextureRegion[5];
    private int roll;
    private int count;
    private boolean changeForm;


    public BacteriaBlue(float x, float y, GameMap map) {
        super(x, y, EntityType.BACTERIABLUE, map);
        blueComplete = false;

        setID(blueCount);
        blueCount += 1;

        //THIS IS FOR TESTING
        System.out.println("Current blue count: ");
        System.out.println(blueCount);
        System.out.println("I am bacteria " + getID());
        System.out.println("My x1 pos is: " + pos.x);
        System.out.println("My y1 pos is: " + pos.y);
        System.out.println("My x2 pos is: " + posR.x);
        System.out.println("My y2 pos is: " + posR.y);
        //TESTING END

        //Animation Testing
        image = new Texture("ZeroSpore.png");
        regions[0] = new TextureRegion(image, 0, 0, 128,128);
        regions[1] = new TextureRegion(image, 128, 0, 128,128);
        regions[2] = new TextureRegion(image, 256, 0, 128,128);
        regions[3] = new TextureRegion(image, 0, 128, 128,128);
        regions[4] = new TextureRegion(image, 128, 128, 128,128);
        roll = 0;
        count = 0;
        //regions[6] = new TextureRegion(tempTex, 256, 128, 128,128);

    }

    @Override
    public void update(float deltaTime, float gravity){
        super.update(deltaTime, gravity);

        if(getBlueComplete()){
            if(Math.floor(getY())>((map.getHeight()*16)/2)){
                moveY(-getSpeed()*deltaTime);
                //System.out.println("My y is: " + getY());
                //System.out.println("Moving too: " + (map.getHeight()*16)/2);
            }
            else if(Math.ceil(getY())<((map.getHeight()*16)/2)){
                moveY(getSpeed()*deltaTime);
                //System.out.println("My y is: " + getY());
                //System.out.println("Moving too: " + (map.getHeight()*16)/2);
            }else{
                //System.out.println("CHUR");
                setInPlaceY();
            }
            if(Math.floor(getX()) > (((map.getWidth())*16)/6)*(getID()+1)){
                moveX(-getSpeed()*deltaTime);
            }
            else if(Math.ceil(getX()) < (((map.getWidth())*16)/6)*(getID()+1)){
                moveX(getSpeed()*deltaTime);
            }else{
                //System.out.println("Skeet skeet");
                setInPlaceX();
            }

        }

        for (BacteriaGeneral blue : otherBlue.getBacteriaArray()) {
            if (blue == null) {
                //This bacteria has not been spawned yet.
                //System.out.println("Ok this will work");
                continue;
            } else if (blue.getID() == this.getID()) {
                //This blue bacteria is myself, no interactions with self (or own spores) is needed.

                continue;
                //System.out.println("Hey that's me!" + blue.getID() + " " + this.getID());
                //System.out.println(blue.getPos().x);
                //System.out.println(this.getPos().x);
            } else {
                //Check through the spores of this bacteria to see if any are touching me
                //System.out.println("That ain't me." + blue.getID() + " " + this.getID());
                for (Spore bindableSpore : blue.getMyspores()) {
                    if ((bindableSpore.pos.x >= this.pos.x && bindableSpore.pos.x <= this.posR.x) && (bindableSpore.pos.y >= this.pos.y && bindableSpore.pos.y <= this.posR.y)) {
                        if (checkBinding(bindableSpore.pos.x, bindableSpore.pos.y, EntityType.SPORE)) {

                            if (otherBlue.getBacteriaToAlter() == null) {

                                otherBlue.setTempSpore(bindableSpore);
                                otherBlue.setBacteriaToAlter(blue);
                            }
                            //otherBlue.getBacteriaToAlter().getMyspores().remove(otherBlue.getTempSpore());


                        }

                        //System.out.println("\n\n");
                        //System.out.println("We cookin" + blue.getID() + this.getID());
                        //System.out.println(blue.pos.x);
                        //System.out.println(this.pos.x);

                    }
                }

            }
        }

        if(otherBlue.getBacteriaToAlter() != null){

            otherBlue.getBacteriaToAlter().getMyspores().remove(otherBlue.getTempSpore());
            otherBlue.setBacteriaToAlter(null);
            otherBlue.setTempSpore(null);
            //Spawns too many spores. Needs to be 4, (5 is good for testing)
            if (this.getSporeCount() < 5) {
                this.getMyspores().add(new Spore(this.getX(), this.getY(), EntityType.SPORE, map, this));
                this.setSporeCount(this.getSporeCount() + 1);
            }
        }

        //for(Spore spore : getMyspores()){
        //    spore.update(deltaTime, gravity);
        //}

        //System.out.println(getID() + " spore count is: " + getSporeCount());

    }

    @Override
    public void render(SpriteBatch batch) {

        if (roll == 5){
            roll = 0;
        }
        /*for(int i = 0; i <regions.length; i++){
            batch.draw(regions[i], pos.x, pos.y, getWidth(), getHeight());
        }*/
        batch.draw(regions[roll], pos.x, pos.y, getWidth(), getHeight());
        super.render(batch);
        count +=1;
        if (count == 10) {
            roll += 1;
            count = 0;
        }
        //Here is replication (or maybe original?)

    }




    public static void setBlueCount(int initialize){
        blueCount = initialize;
    }

    public static boolean getBlueComplete(){
        return blueComplete;
    }

    public static void setBlueComplete(){
        blueComplete = true;
    }

    @Override
    public int getBacteriaCount() {
        return blueCount;
    }

    @Override
    public EntityType getBacteriaType() {
        return this.type;
    }

    @Override
    public void setBlockerBound(EntityType type) {
        super.setBlockerBound(type);
        if(type == EntityType.ANTIBIOTIC){
            image = new Texture("AntiBlockTemp.jpg");
        }
        if(type == EntityType.GARLIC){
            image = new Texture("GarlicBlockTemp.jpg");
        }
        if(type == EntityType.REDENZYME){
            image = new Texture("RedBlockTemp.jpg");
        }
    }

    @Override
    public void checkForm() {
        if(checkBottomLeft()){
            if(checkBottomRight()){
                if(checkTopLeft()){
                    if(checkTopRight()){
                        //ALL POINTS BOUND
                        image = new Texture("ALL.jpg");
                        regions[0] = new TextureRegion(image, 0, 0, 128,128);
                        regions[1] = new TextureRegion(image, 128, 0, 128,128);
                        regions[2] = new TextureRegion(image, 256, 0, 128,128);
                        regions[3] = new TextureRegion(image, 0, 128, 128,128);
                        regions[4] = new TextureRegion(image, 128, 128, 128,128);
                    }
                    else{
                        //Bottom Left, Bottom Right and Top Left
                        image = new Texture("BLBRTL.png");
                        regions[0] = new TextureRegion(image, 0, 0, 128,128);
                        regions[1] = new TextureRegion(image, 128, 0, 128,128);
                        regions[2] = new TextureRegion(image, 256, 0, 128,128);
                        regions[3] = new TextureRegion(image, 0, 128, 128,128);
                        regions[4] = new TextureRegion(image, 128, 128, 128,128);
                        return;
                    }
                }
                else if(checkTopRight()){
                    //Bottom Left, Bottom Right and Top Right
                    image = new Texture("BLBRTR.png");
                    regions[0] = new TextureRegion(image, 0, 0, 128,128);
                    regions[1] = new TextureRegion(image, 128, 0, 128,128);
                    regions[2] = new TextureRegion(image, 256, 0, 128,128);
                    regions[3] = new TextureRegion(image, 0, 128, 128,128);
                    regions[4] = new TextureRegion(image, 128, 128, 128,128);
                    return;
                }
                else{
                    //Bottom Left AND Bottom Right
                    image = new Texture("BLBR.png");
                    regions[0] = new TextureRegion(image, 0, 0, 128,128);
                    regions[1] = new TextureRegion(image, 128, 0, 128,128);
                    regions[2] = new TextureRegion(image, 256, 0, 128,128);
                    regions[3] = new TextureRegion(image, 0, 128, 128,128);
                    regions[4] = new TextureRegion(image, 128, 128, 128,128);
                    return;
                }
            }
            else if(checkTopLeft()){
                if(checkTopRight()){
                    //Bottom Left, Top Left and Top Right
                    image = new Texture("BLTLTR.png");
                    regions[0] = new TextureRegion(image, 0, 0, 128,128);
                    regions[1] = new TextureRegion(image, 128, 0, 128,128);
                    regions[2] = new TextureRegion(image, 256, 0, 128,128);
                    regions[3] = new TextureRegion(image, 0, 128, 128,128);
                    regions[4] = new TextureRegion(image, 128, 128, 128,128);
                    return;
                }
                else{
                    //Bottom Left and Top Left
                    image = new Texture("BLTL.png");
                    regions[0] = new TextureRegion(image, 0, 0, 128,128);
                    regions[1] = new TextureRegion(image, 128, 0, 128,128);
                    regions[2] = new TextureRegion(image, 256, 0, 128,128);
                    regions[3] = new TextureRegion(image, 0, 128, 128,128);
                    regions[4] = new TextureRegion(image, 128, 128, 128,128);
                    return;
                }
            }
            else if(checkTopRight()){
                //Bottom Left and Top Right
                image = new Texture("BLTR.png");
                regions[0] = new TextureRegion(image, 0, 0, 128,128);
                regions[1] = new TextureRegion(image, 128, 0, 128,128);
                regions[2] = new TextureRegion(image, 256, 0, 128,128);
                regions[3] = new TextureRegion(image, 0, 128, 128,128);
                regions[4] = new TextureRegion(image, 128, 128, 128,128);
                return;
            }
            else{
                //Bottom Left
                image = new Texture("BL.png");
                regions[0] = new TextureRegion(image, 0, 0, 128,128);
                regions[1] = new TextureRegion(image, 128, 0, 128,128);
                regions[2] = new TextureRegion(image, 256, 0, 128,128);
                regions[3] = new TextureRegion(image, 0, 128, 128,128);
                regions[4] = new TextureRegion(image, 128, 128, 128,128);
                return;
            }
        }
        else if (checkBottomRight()){
            if(checkTopLeft()){
                if(checkTopRight()){
                    //Bottom Right, Top Left and Top Right
                    image = new Texture("BRTLTR.png");
                    regions[0] = new TextureRegion(image, 0, 0, 128,128);
                    regions[1] = new TextureRegion(image, 128, 0, 128,128);
                    regions[2] = new TextureRegion(image, 256, 0, 128,128);
                    regions[3] = new TextureRegion(image, 0, 128, 128,128);
                    regions[4] = new TextureRegion(image, 128, 128, 128,128);
                    return;
                }
                else{
                    //Bottom Right and Top Left
                    image = new Texture("BRTL.png");
                    regions[0] = new TextureRegion(image, 0, 0, 128,128);
                    regions[1] = new TextureRegion(image, 128, 0, 128,128);
                    regions[2] = new TextureRegion(image, 256, 0, 128,128);
                    regions[3] = new TextureRegion(image, 0, 128, 128,128);
                    regions[4] = new TextureRegion(image, 128, 128, 128,128);
                    return;
                }
            }
            else if(checkTopRight()){
                //Bottom Right and Top Right
                image = new Texture("BRTR.png");
                regions[0] = new TextureRegion(image, 0, 0, 128,128);
                regions[1] = new TextureRegion(image, 128, 0, 128,128);
                regions[2] = new TextureRegion(image, 256, 0, 128,128);
                regions[3] = new TextureRegion(image, 0, 128, 128,128);
                regions[4] = new TextureRegion(image, 128, 128, 128,128);
                return;
            }
            else{
                //Bottom Right
                image = new Texture("BR.png");
                regions[0] = new TextureRegion(image, 0, 0, 128,128);
                regions[1] = new TextureRegion(image, 128, 0, 128,128);
                regions[2] = new TextureRegion(image, 256, 0, 128,128);
                regions[3] = new TextureRegion(image, 0, 128, 128,128);
                regions[4] = new TextureRegion(image, 128, 128, 128,128);
                return;
            }
        }
        else if (checkTopLeft()){
            if(checkTopRight()){
                //Top Left and Top Right
                image = new Texture("TLTR.png");
                regions[0] = new TextureRegion(image, 0, 0, 128,128);
                regions[1] = new TextureRegion(image, 128, 0, 128,128);
                regions[2] = new TextureRegion(image, 256, 0, 128,128);
                regions[3] = new TextureRegion(image, 0, 128, 128,128);
                regions[4] = new TextureRegion(image, 128, 128, 128,128);
                return;
            }
            else{
                //Top Left
                image = new Texture("TL.png");
                regions[0] = new TextureRegion(image, 0, 0, 128,128);
                regions[1] = new TextureRegion(image, 128, 0, 128,128);
                regions[2] = new TextureRegion(image, 256, 0, 128,128);
                regions[3] = new TextureRegion(image, 0, 128, 128,128);
                regions[4] = new TextureRegion(image, 128, 128, 128,128);
                return;
            }
        }
        else if (checkTopRight()){
            //Top Right
            image = new Texture("TR.png");
            regions[0] = new TextureRegion(image, 0, 0, 128,128);
            regions[1] = new TextureRegion(image, 128, 0, 128,128);
            regions[2] = new TextureRegion(image, 256, 0, 128,128);
            regions[3] = new TextureRegion(image, 0, 128, 128,128);
            regions[4] = new TextureRegion(image, 128, 128, 128,128);
            return;
        }
        else{
            //No bindings as yet.
            return;
        }
    }

    public static void getInfo(BacteriaInfo bacteriaUpdate){
        otherBlue = bacteriaUpdate;
    }


}
