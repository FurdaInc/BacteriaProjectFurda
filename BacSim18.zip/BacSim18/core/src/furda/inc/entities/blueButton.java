package furda.inc.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import furda.inc.world.GameMap;
import furda.inc.world.TiledGameMap;

public class blueButton extends Entity {

    Texture image;
    Vector3 mousePos;
    EntityType spawnerType;

    public blueButton(float x, float y, GameMap map, Texture buttonType, EntityType spawnerType) {

        super(x, y, EntityType.BLUEBUTTON, map);
        image = buttonType;
        this.spawnerType = spawnerType;
    }


    @Override
    public void update(float deltaTime, float gravity) {
        super.update(deltaTime, gravity);
        mousePos = getMousePosInMap(map.returnCam());
        //int x = Gdx.input.getX() - 150;
        //int y = Gdx.input.getY() + 15;
        float x = mousePos.x;
        float y = mousePos.y;
        //if(this.clicked();)
        if((x>=pos.x&&x<=(pos.x+this.getWidth())) && (y>=pos.y&&y<=(pos.y+this.getHeight()))) {
            if (Gdx.input.justTouched()) {
                if(spawnerType == EntityType.BACTERIABLUE)
                    map.setUpdateBlue();
                if(spawnerType == EntityType.BACTERIARED)
                    map.setUpdateRed();
                if(spawnerType == EntityType.WBC)
                    map.setUpdateWBC();
                if(spawnerType == EntityType.ANTIBIOTIC)
                    map.setUpdateAntiBiotics();
                if(spawnerType == EntityType.GARLIC)
                    map.setUpdateGarlic();
            }
        }
        //System.out.println("Mouse pos: " + y);
        //System.out.println("Lower bound: " + pos.y);
        //System.out.println("Upper bound: " + (pos.y + this.getHeight()));
        //System.out.println(this.getWidth());



    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(image, pos.x, pos.y, getWidth(), getHeight());
    }

    @Override
    public void playAnimation() {

    }

}
