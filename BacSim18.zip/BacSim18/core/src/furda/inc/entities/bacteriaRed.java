package furda.inc.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;


public class bacteriaRed extends bacteriaGeneral {

    public static int redCount = 0;


    Texture image;
    TextureRegion[] redSpriteRoll = new TextureRegion[5];


    public bacteriaRed(float x, float y, GameMap map) {

        super(x, y, EntityType.BACTERIARED, map);
        //Intializes the picture of the bactera

        redCount++;
        setID(redCount);

        //TextureRegion[][] rollSpriteSheet = TextureRegion.split(new Texture("RedBacteria.png"), 80, 80);
        redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\0. Zero Spore\\New_Red_Idle1.png"),128,128);
        redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\0. Zero Spore\\New_Red_Idle2.png"),128,128);
        redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\0. Zero Spore\\New_Red_Idle3.png"),128,128);
        redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\0. Zero Spore\\New_Red_Idle4.png"),128,128);
        redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\0. Zero Spore\\New_Red_Idle5.png"),128,128);
        //rolls[roll] = new Animation(ANIMATION_SPEED, rollSpriteSheet[0]);
        rolls[roll] = new Animation(ANIMATION_SPEED, redSpriteRoll);


        //image = new Texture("Karsa.jpg");
    }

    @Override
    public void update(float deltaTime, float gravity) {
        /*if(Gdx.input.isKeyPressed(Keys.SPACE)){
            this.velocityY += JUMP_VELOCITY * getweight();
            //We multiply by deltaTime below to reduce the max height of the jump
            //IF not the jump would just kind continue?
        }else if(Gdx.input.isKeyPressed(Keys.SPACE) && !grounded && this.velocityY >0){
            this.velocityY += JUMP_VELOCITY * getweight() * deltaTime;
        }*/
        super.update(deltaTime, gravity); //This is what applys the gravity

        //Here we use negative speed as we are moving char to the left
        if(Gdx.input.isKeyPressed(Keys.LEFT))
            moveX(-SPEED * deltaTime);

        if(Gdx.input.isKeyPressed(Keys.RIGHT))
            moveX(SPEED * deltaTime);

        if(Gdx.input.isKeyPressed(Keys.UP))
            moveY(SPEED * deltaTime);

        if(Gdx.input.isKeyPressed(Keys.DOWN))
            moveY(-SPEED * deltaTime);

        //System.out.println("Cell loc" + this.getX());
    }

    @Override
    public void render(SpriteBatch batch) {
        //Here we specify where the player is to be spawned (pos.x pos.y)
        //The getWidth and getHeight specify the dimensions that the player should occupy
        //batch.draw(image, pos.x, pos.y, getWidth(), getHeight());

        stateTime += Gdx.graphics.getDeltaTime();
        batch.draw((TextureRegion) rolls[roll].getKeyFrame((float) stateTime,true), pos.x, pos.y,getWidth(),getHeight());
    }

    public void changeForm(){
        boundSpores++;
        if(bottomLeft){
            this.BLbound = true;
            if(bottomRight&&topLeft&&topRight){ // If all slots are bound
                //Simulation Animation (Re-ordered)\Red Bacteria Animation\
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Red Bacteria Animation\4. Four Spores\4.1.1 Four Spores Left + Right + Bottom + Top
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\4. Four Spores\\Four_Spores_All_Excpt_Blupng1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\4. Four Spores\\Four_Spores_All_Excpt_Blupng2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\4. Four Spores\\Four_Spores_All_Excpt_Blupng3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\4. Four Spores\\Four_Spores_All_Excpt_Blupng4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\4. Four Spores\\Four_Spores_All_Excpt_Blupng5.png"),128,128);
            }else if(bottomRight&&topLeft){ // If bottom left, bottom right and top left are bound
                redSpriteRoll[0] = new TextureRegion(new Texture("BlueBacteria1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("BlueBacteria2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("BlueBacteria3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("BlueBacteria4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("BlueBacteria5.png"),128,128);
            }else if(bottomRight&&topRight){ //If bottom left, bottom right and top right are bound
                redSpriteRoll[0] = new TextureRegion(new Texture("BlueBacteria1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("BlueBacteria2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("BlueBacteria3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("BlueBacteria4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("BlueBacteria5.png"),128,128);
            }else if(topLeft&&topRight){
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\3. Three Spores\\3.1 Three Spores Bottom\\3.1.2 Left + Right + Top\\Three_Spores_Lft_Rht_Top1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\3. Three Spores\\3.1 Three Spores Bottom\\3.1.2 Left + Right + Top\\Three_Spores_Lft_Rht_Top2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\3. Three Spores\\3.1 Three Spores Bottom\\3.1.2 Left + Right + Top\\Three_Spores_Lft_Rht_Top3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\3. Three Spores\\3.1 Three Spores Bottom\\3.1.2 Left + Right + Top\\Three_Spores_Lft_Rht_Top4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\3. Three Spores\\3.1 Three Spores Bottom\\3.1.2 Left + Right + Top\\Three_Spores_Lft_Rht_Top5.png"),128,128);
            }else if(bottomRight){
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.1 Left + Bottom\\Two_Spores_Lft-Bot1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.1 Left + Bottom\\Two_Spores_Lft-Bot2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.1 Left + Bottom\\Two_Spores_Lft-Bot3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.1 Left + Bottom\\Two_Spores_Lft-Bot4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.1 Left + Bottom\\Two_Spores_Lft-Bot5.png"),128,128);
            }else if(topRight){
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.2 Left + Right\\Two_Spores_Lft-Rht1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.2 Left + Right\\Two_Spores_Lft-Rht2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.2 Left + Right\\Two_Spores_Lft-Rht3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.2 Left + Right\\Two_Spores_Lft-Rht4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.2 Left + Right\\Two_Spores_Lft-Rht5.png"),128,128);
            }else if(topLeft){
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.3 Left + Top\\Two_Spores_Lft-Top1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.3 Left + Top\\Two_Spores_Lft-Top2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.3 Left + Top\\Two_Spores_Lft-Top3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.3 Left + Top\\Two_Spores_Lft-Top4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.2 Two Spores Left\\2.2.3 Left + Top\\Two_Spores_Lft-Top5.png"),128,128);
            }else{
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.3 Single Spore Left\\Single_Spore_Left1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.3 Single Spore Left\\Single_Spore_Left2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.3 Single Spore Left\\Single_Spore_Left3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.3 Single Spore Left\\Single_Spore_Left4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.3 Single Spore Left\\Single_Spore_Left5.png"),128,128);
            }

        }
        else if(bottomRight){
            this.BRbound = true;
            if(topLeft&&topRight){ // If bottom right, top left and top right are bound
                redSpriteRoll[0] = new TextureRegion(new Texture("BlueBacteria1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("BlueBacteria2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("BlueBacteria3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("BlueBacteria4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("BlueBacteria5.png"),128,128);
            }else if(topLeft){ // If bottom right and top left are bound
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Red Bacteria Animation\2. Two Spores  pos 1 - 5\2.3 Two Spores Right\Two_Spores_Rht-Top1.png
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.3 Two Spores Right\\2.1.3 Bottom + Top\\Two_Spores_Bot-Top1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.3 Two Spores Right\\2.1.3 Bottom + Top\\Two_Spores_Bot-Top1.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.3 Two Spores Right\\2.1.3 Bottom + Top\\Two_Spores_Bot-Top1.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.3 Two Spores Right\\2.1.3 Bottom + Top\\Two_Spores_Bot-Top1.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.3 Two Spores Right\\2.1.3 Bottom + Top\\Two_Spores_Bot-Top1.png"),128,128);
            }else if(topRight){ // If bottom right and top right are bound
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.1 Two Spores Bottom\\2.1.1 Bottom + Right\\Two_Spores_Bot-Rht1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.1 Two Spores Bottom\\2.1.1 Bottom + Right\\Two_Spores_Bot-Rht2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.1 Two Spores Bottom\\2.1.1 Bottom + Right\\Two_Spores_Bot-Rht3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.1 Two Spores Bottom\\2.1.1 Bottom + Right\\Two_Spores_Bot-Rht4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.1 Two Spores Bottom\\2.1.1 Bottom + Right\\Two_Spores_Bot-Rht5.png"),128,128);
            }else{ // If only Bottom right is bound
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.1 Single Spore Bottom\\Single_Spore_Bottom1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.1 Single Spore Bottom\\Single_Spore_Bottom2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.1 Single Spore Bottom\\Single_Spore_Bottom3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.1 Single Spore Bottom\\Single_Spore_Bottom4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.1 Single Spore Bottom\\Single_Spore_Bottom5.png"),128,128);
            }

        }
        else if(topLeft){
            this.TLbound = true;
            if(topRight) { // If top left and top right are bound
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Red Bacteria Animation\2. Two Spores  pos 1 - 5\2.4 Two Spores Top\2.4.3 Top + Right
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.4 Two Spores Top\\2.4.3 Top + Right\\Two_Spores_Top-Rht1.png"), 128, 128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.4 Two Spores Top\\2.4.3 Top + Right\\Two_Spores_Top-Rht2.png"), 128, 128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.4 Two Spores Top\\2.4.3 Top + Right\\Two_Spores_Top-Rht3.png"), 128, 128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.4 Two Spores Top\\2.4.3 Top + Right\\Two_Spores_Top-Rht4.png"), 128, 128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\2. Two Spores  pos 1 - 5\\2.4 Two Spores Top\\2.4.3 Top + Right\\Two_Spores_Top-Rht5.png"), 128, 128);
            }else{ // If only top left is bound
                redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.4 Single Spore Top\\Single_Spore_Top1.png"),128,128);
                redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.4 Single Spore Top\\Single_Spore_Top2.png"),128,128);
                redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.4 Single Spore Top\\Single_Spore_Top3.png"),128,128);
                redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.4 Single Spore Top\\Single_Spore_Top4.png"),128,128);
                redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.4 Single Spore Top\\Single_Spore_Top5.png"),128,128);
            }
        }
        else if(topRight){ // If only top right is bound
            this.TRbound = true;
            //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Red Bacteria Animation\1. Single Spore pos 1 - 5\1.2 Single Spore Right
            redSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.2 Single Spore Right\\Single_Spore_Right1.png"),128,128);
            redSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.2 Single Spore Right\\Single_Spore_Right2.png"),128,128);
            redSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.2 Single Spore Right\\Single_Spore_Right3.png"),128,128);
            redSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.2 Single Spore Right\\Single_Spore_Right4.png"),128,128);
            redSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Red Bacteria Animation\\1. Single Spore pos 1 - 5\\1.2 Single Spore Right\\Single_Spore_Right5.png"),128,128);
        }
        //TextureRegion[][] rollSpriteSheet = TextureRegion.split(new Texture("BacteriaRed.png"), 201, 130);
        rolls[roll] = new Animation(ANIMATION_SPEED, redSpriteRoll);
    }

    public void makeEnzyme(){
        System.out.println("Here is where we make the killer enzyme.");
    }


}

