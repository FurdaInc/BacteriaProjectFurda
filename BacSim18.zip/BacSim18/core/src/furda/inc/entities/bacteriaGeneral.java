package furda.inc.entities;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import furda.inc.world.GameMap;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class bacteriaGeneral extends Entity {

    protected static final int SPEED = 80;
    private static final int JUMP_VELOCITY = 1;
    Vector3 mousePos;


    public static  final float ANIMATION_SPEED = 0.5f;
    Animation[] rolls;
    int roll;
    double stateTime = Math.random();

    public static boolean[] control = new boolean[4];



    boolean topLeft=false, topRight=false, bottomLeft=false, bottomRight=false;
    boolean TLbound=false, TRbound=false, BLbound=false, BRbound=false;

    int boundSpores;





    public bacteriaGeneral(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        roll = 1;
        rolls = new Animation[5];
        boundSpores = 0;
        control[0] = false;
        control[1] = false;
        control[2] = false;
        control[3] = false;



    }

    @Override
    public void render(SpriteBatch batch) {

    }

    @Override
    public void playAnimation() {

    }

    public void setBindPoint(int x){

        if (x == 1){

            bottomLeft = true;
        }
        if (x == 2){

            bottomRight = true;
        }
        if (x == 3){

            topLeft = true;
        }
        if (x == 4){

            topRight = true;
        }
        System.out.println("Bacteria " + this.returnID() + "Set bind point: " + x);
    }
    public boolean TLbound(){
        return TLbound;
    }

    public boolean TRbound(){
        return TRbound;
    }

    public boolean BLbound(){
        return BLbound;
    }

    public boolean BRbound(){
        return BRbound;
    }

    public boolean isTopLeft() {
        return topLeft;
    }

    public boolean isTopRight() {
        return topRight;
    }

    public boolean isBottomLeft() {
        return bottomLeft;
    }

    public boolean isBottomRight() {
        return bottomRight;
    }

    public int getSporeCount(){
        return boundSpores;
    }

    public boolean getComplete(){
        if((TRbound||topRight) && (TLbound||topLeft) && (BRbound||bottomRight) && (BLbound||bottomLeft))
            return true;
        return false;
    }

    public static void setControl(int id) {
        for(int i=0; i<4; i++)
            control[i] = false;

        control[id] = true;
    }
}
