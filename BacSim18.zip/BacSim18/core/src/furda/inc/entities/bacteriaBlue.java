package furda.inc.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;


public class bacteriaBlue extends bacteriaGeneral {

    public static int blueCount = 0;

    Texture image;
    TextureRegion[] blueSpriteRoll = new TextureRegion[5];

    public bacteriaBlue(float x, float y, GameMap map) {

        super(x, y, EntityType.BACTERIABLUE, map);
        //Intializes the picture of the player

        blueCount++;
        setID(blueCount);



        //TextureRegion[][] rollSpriteSheet = TextureRegion.split(new Texture("Bacteria.png"), 201, 130);
        //rolls[roll] = new Animation(ANIMATION_SPEED, blueSpriteRoll);
        blueSpriteRoll[0] = new TextureRegion(new Texture("BlueBacteria1.png"),128,128);
        blueSpriteRoll[1] = new TextureRegion(new Texture("BlueBacteria2.png"),128,128);
        blueSpriteRoll[2] = new TextureRegion(new Texture("BlueBacteria3.png"),128,128);
        blueSpriteRoll[3] = new TextureRegion(new Texture("BlueBacteria4.png"),128,128);
        blueSpriteRoll[4] = new TextureRegion(new Texture("BlueBacteria5.png"),128,128);
        rolls[roll] = new Animation(ANIMATION_SPEED, blueSpriteRoll);


        //image = new Texture("Karsa.jpg");
    }

    @Override
    public void update(float deltaTime, float gravity) {
        /*if(Gdx.input.isKeyPressed(Keys.SPACE)){
            this.velocityY += JUMP_VELOCITY * getweight();
            //We multiply by deltaTime below to reduce the max height of the jump
            //IF not the jump would just kind continue?
        }else if(Gdx.input.isKeyPressed(Keys.SPACE) && !grounded && this.velocityY >0){
            this.velocityY += JUMP_VELOCITY * getweight() * deltaTime;
        }*/
        super.update(deltaTime, gravity); //This is what applys the gravity
        //System.out.println(pos.x + " " + pos.y);



        mousePos = getMousePosInMap(map.returnCam());

        float x = mousePos.x;
        float y = mousePos.y;

        if((x>=pos.x&&x<=(pos.x+this.getWidth())) && (y>=pos.y&&y<=(pos.y+this.getHeight()))) {
            if (Gdx.input.justTouched()) {
                bacteriaGeneral.setControl(this.returnID()-1);
            }
        }
        //Here we use negative speed as we are moving char to the left
        if(control[this.returnID()-1]) {
            if (Gdx.input.isKeyPressed(Keys.LEFT))
                moveX(-SPEED * deltaTime);

            if (Gdx.input.isKeyPressed(Keys.RIGHT))
                moveX(SPEED * deltaTime);

            if (Gdx.input.isKeyPressed(Keys.UP))
                moveY(SPEED * deltaTime);

            if (Gdx.input.isKeyPressed(Keys.DOWN))
                moveY(-SPEED * deltaTime);
        }

        this.checkBinding(this.type);

        //System.out.println("Cell loc" + this.getX());
    }

    @Override
    public void render(SpriteBatch batch) {
        //Here we specify where the player is to be spawned (pos.x pos.y)
        //The getWidth and getHeight specify the dimensions that the player should occupy
        //batch.draw(image, pos.x, pos.y, getWidth(), getHeight());

        stateTime += Gdx.graphics.getDeltaTime();
        batch.draw((TextureRegion) rolls[roll].getKeyFrame((float) stateTime,true), pos.x, pos.y,getWidth(),getHeight());
    }



    public void changeForm(){
        boundSpores++;
        System.out.println("Spore count: " + boundSpores);
        if(bottomLeft){
            this.BLbound = true;
            //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Blue Bacteria Animation\Spore Position Animation\4. Four Spore\4.1 Complete
            if(bottomRight&&topLeft&&topRight){ // If all slots are bound
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\4. Four Spore\\4.1 Complete\\Blue_Bacteria_All1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\4. Four Spore\\4.1 Complete\\Blue_Bacteria_All2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\4. Four Spore\\4.1 Complete\\Blue_Bacteria_All3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\4. Four Spore\\4.1 Complete\\Blue_Bacteria_All4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\4. Four Spore\\4.1 Complete\\Blue_Bacteria_All5.png"),128,128);
            }else if(bottomRight&&topLeft){ // If bottom left, bottom right and top left are bound
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Blue Bacteria Animation\Spore Position Animation\3. Three Spore\All variations\3.1.1 Bottom Left + Bottom Right + Top Left
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.1 Bottom Left + Bottom Right + Top Left\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Lft1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.1 Bottom Left + Bottom Right + Top Left\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Lft2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.1 Bottom Left + Bottom Right + Top Left\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Lft3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.1 Bottom Left + Bottom Right + Top Left\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Lft4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.1 Bottom Left + Bottom Right + Top Left\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Lft5.png"),128,128);
            }else if(bottomRight&&topRight){ //If bottom left, bottom right and top right are bound
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.2 Bottom Left + Bottom Right + Top Right\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Rht1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.2 Bottom Left + Bottom Right + Top Right\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Rht2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.2 Bottom Left + Bottom Right + Top Right\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Rht3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.2 Bottom Left + Bottom Right + Top Right\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Rht4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.2 Bottom Left + Bottom Right + Top Right\\Blue_Bacteria_Bot_Lft_Bot_Rht_Top_Rht5.png"),128,128);
            }else if(topLeft&&topRight){
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.3 Top Left + Top Right + Bottom Left\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Lft1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.3 Top Left + Top Right + Bottom Left\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Lft2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.3 Top Left + Top Right + Bottom Left\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Lft3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.3 Top Left + Top Right + Bottom Left\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Lft4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.3 Top Left + Top Right + Bottom Left\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Lft5.png"),128,128);
            }else if(bottomRight){
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Blue Bacteria Animation\Spore Position Animation\2. Two Spore\2.1 Two Spore Bottom Left\2.1.1 Bottom Left + Bottom Right
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.1 Bottom Left + Bottom Right\\Blue_Bacteria_Bot_Left_Bot_Right1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.1 Bottom Left + Bottom Right\\Blue_Bacteria_Bot_Left_Bot_Right2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.1 Bottom Left + Bottom Right\\Blue_Bacteria_Bot_Left_Bot_Right3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.1 Bottom Left + Bottom Right\\Blue_Bacteria_Bot_Left_Bot_Right4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.1 Bottom Left + Bottom Right\\Blue_Bacteria_Bot_Left_Bot_Right5.png"),128,128);
            }else if(topRight){
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.3 Bottom Left + Top Right\\Blue_Bacteria_Bot_Left_Top_Right1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.3 Bottom Left + Top Right\\Blue_Bacteria_Bot_Left_Top_Right2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.3 Bottom Left + Top Right\\Blue_Bacteria_Bot_Left_Top_Right3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.3 Bottom Left + Top Right\\Blue_Bacteria_Bot_Left_Top_Right4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.3 Bottom Left + Top Right\\Blue_Bacteria_Bot_Left_Top_Right5.png"),128,128);
            }else if(topLeft){
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.2 Bottom Left + Top Left\\Blue_Bacteria_Bot_Left_Top_Left1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.2 Bottom Left + Top Left\\Blue_Bacteria_Bot_Left_Top_Left2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.2 Bottom Left + Top Left\\Blue_Bacteria_Bot_Left_Top_Left3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.2 Bottom Left + Top Left\\Blue_Bacteria_Bot_Left_Top_Left4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.1 Two Spore Bottom Left\\2.1.2 Bottom Left + Top Left\\Blue_Bacteria_Bot_Left_Top_Left5.png"),128,128);
            }else{
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Blue Bacteria Animation\Spore Position Animation\1. Single Spore\1.1 Single Spore Bottom Left
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.1 Single Spore Bottom Left\\Blue_Bacteria_Bottom_Left1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.1 Single Spore Bottom Left\\Blue_Bacteria_Bottom_Left2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.1 Single Spore Bottom Left\\Blue_Bacteria_Bottom_Left3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.1 Single Spore Bottom Left\\Blue_Bacteria_Bottom_Left4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.1 Single Spore Bottom Left\\Blue_Bacteria_Bottom_Left5.png"),128,128);
            }

        }
        else if(bottomRight){
            this.BRbound = true;
            if(topLeft&&topRight){ // If bottom right, top left and top right are bound
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Blue Bacteria Animation\Spore Position Animation\3. Three Spore\All variations\3.1.4 Top Left + Top Right + Bottom Right
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.4 Top Left + Top Right + Bottom Right\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Rht1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.4 Top Left + Top Right + Bottom Right\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Rht2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.4 Top Left + Top Right + Bottom Right\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Rht3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.4 Top Left + Top Right + Bottom Right\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Rht4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\3. Three Spore\\3.1.4 Top Left + Top Right + Bottom Right\\Blue_Bacteria_Top_Lft_Top_Rht_Bot_Rht5.png"),128,128);
            }else if(topLeft){ // If bottom right and top left are bound
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Blue Bacteria Animation\Spore Position Animation\2. Two Spore\2.2 Two Spore Bottom Right\2.2.1 Bottom Right + Top Left
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.1 Bottom Right + Top Left\\Blue_Bacteria_Bot_Right_Top_Leftt1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.1 Bottom Right + Top Left\\Blue_Bacteria_Bot_Right_Top_Leftt2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.1 Bottom Right + Top Left\\Blue_Bacteria_Bot_Right_Top_Leftt3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.1 Bottom Right + Top Left\\Blue_Bacteria_Bot_Right_Top_Leftt4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.1 Bottom Right + Top Left\\Blue_Bacteria_Bot_Right_Top_Leftt5.png"),128,128);
            }else if(topRight){ // If bottom right and top right are bound
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.2 Bottom Right + Top Right\\Blue_Bacteria_Bot_Right_Top_Right1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.2 Bottom Right + Top Right\\Blue_Bacteria_Bot_Right_Top_Right2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.2 Bottom Right + Top Right\\Blue_Bacteria_Bot_Right_Top_Right3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.2 Bottom Right + Top Right\\Blue_Bacteria_Bot_Right_Top_Right4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.2 Two Spore Bottom Right\\2.2.2 Bottom Right + Top Right\\Blue_Bacteria_Bot_Right_Top_Right5.png"),128,128);
            }else{ // If only Bottom right is bound
                //C:\Users\Stein\Documents\BEAN project\The second wave\BacSim17\core\assets\Simulation Animation (Re-ordered)\Blue Bacteria Animation\Spore Position Animation\1. Single Spore\1.2 Single Spore Bottom Right
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.2 Single Spore Bottom Right\\Blue_Bacteria_Bottom_Right1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.2 Single Spore Bottom Right\\Blue_Bacteria_Bottom_Right2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.2 Single Spore Bottom Right\\Blue_Bacteria_Bottom_Right3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.2 Single Spore Bottom Right\\Blue_Bacteria_Bottom_Right4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.2 Single Spore Bottom Right\\Blue_Bacteria_Bottom_Right5.png"),128,128);
            }

        }
        else if(topLeft){
            this.TLbound = true;
            if(topRight) { // If top left and top right are bound
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.3 Two Spore Top Left\\2.3.1 Top Left + Top Right\\Blue_Bacteria_Top_Left_Top_Right1.png"), 128, 128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.3 Two Spore Top Left\\2.3.1 Top Left + Top Right\\Blue_Bacteria_Top_Left_Top_Right2.png"), 128, 128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.3 Two Spore Top Left\\2.3.1 Top Left + Top Right\\Blue_Bacteria_Top_Left_Top_Right3.png"), 128, 128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.3 Two Spore Top Left\\2.3.1 Top Left + Top Right\\Blue_Bacteria_Top_Left_Top_Right4.png"), 128, 128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\2. Two Spore\\2.3 Two Spore Top Left\\2.3.1 Top Left + Top Right\\Blue_Bacteria_Top_Left_Top_Right5.png"), 128, 128);
            }else{ // If only top left is bound
                blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.3 Single Spore Top Left\\Blue_Bacteria_Top_Left1.png"),128,128);
                blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.3 Single Spore Top Left\\Blue_Bacteria_Top_Left2.png"),128,128);
                blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.3 Single Spore Top Left\\Blue_Bacteria_Top_Left3.png"),128,128);
                blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.3 Single Spore Top Left\\Blue_Bacteria_Top_Left4.png"),128,128);
                blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.3 Single Spore Top Left\\Blue_Bacteria_Top_Left5.png"),128,128);
            }
        }
        else if(topRight){ // If only top right is bound
            this.TRbound = true;
            blueSpriteRoll[0] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.4 Single Spore Top Right\\Blue_Bacteria_Top_Right1.png"),128,128);
            blueSpriteRoll[1] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.4 Single Spore Top Right\\Blue_Bacteria_Top_Right2.png"),128,128);
            blueSpriteRoll[2] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.4 Single Spore Top Right\\Blue_Bacteria_Top_Right3.png"),128,128);
            blueSpriteRoll[3] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.4 Single Spore Top Right\\Blue_Bacteria_Top_Right4.png"),128,128);
            blueSpriteRoll[4] = new TextureRegion(new Texture("Simulation Animation (Re-ordered)\\Blue Bacteria Animation\\Spore Position Animation\\1. Single Spore\\1.4 Single Spore Top Right\\Blue_Bacteria_Top_Right5.png"),128,128);
        }
        //TextureRegion[][] rollSpriteSheet = TextureRegion.split(new Texture("BacteriaRed.png"), 201, 130);
        rolls[roll] = new Animation(ANIMATION_SPEED, blueSpriteRoll);

        System.out.println("Spore count current: " + blueSporeCount);
    }


}
