package furda.inc.entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;

public class blueFinal extends bacteriaGeneral {

    TextureRegion[] blueFinalRoll = new TextureRegion[5];
    public blueFinal(float x, float y, GameMap map) {
        super(x, y, EntityType.BLUEFINAL, map);
        blueFinalRoll[0] = new TextureRegion(new Texture("Karsa.jpg"),128,128);
        blueFinalRoll[1] = new TextureRegion(new Texture("Randy.jpg"),128,128);
        blueFinalRoll[2] = new TextureRegion(new Texture("Karsa.jpg"),128,128);
        blueFinalRoll[3] = new TextureRegion(new Texture("Randy.jpg"),128,128);
        blueFinalRoll[4] = new TextureRegion(new Texture("SamBobandy.jpg"),128,128);
        rolls[roll] = new Animation(ANIMATION_SPEED, blueFinalRoll);
    }

    @Override
    public void render(SpriteBatch batch) {
        stateTime += Gdx.graphics.getDeltaTime();
        batch.draw((TextureRegion) rolls[roll].getKeyFrame((float) stateTime,true), pos.x, pos.y,getWidth(),getHeight());

    }

    @Override
    public void playAnimation() {

    }
}
