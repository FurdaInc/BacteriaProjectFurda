<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="CellTiles" tilewidth="92" tileheight="92" tilecount="24" columns="12">
 <image source="CellTiles.png" width="1107" height="184"/>
</tileset>
