package furda.inc.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import furda.inc.simBase;

import java.awt.*;


public class DesktopLauncher {
	static Dimension screenSize;
	public static void main (String[] arg) {

		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		//config.fullscreen = true;
		config.height = screenSize.height;
		config.width = screenSize.width;

		new LwjglApplication(new simBase(), config);
	}
}
