package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

import java.util.concurrent.ThreadLocalRandom;

public abstract class Particles extends Entity {

    protected Texture image;
    //Play around with speed
    protected static final int SPEED = 80*4;

    protected int lastD1, lastD2;
    protected int Direction;





    public Particles(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        lastD1 = 0;
        lastD2 = 0;


    }

    @Override
    public void update(float deltaTime, float gravity){

        //Make an array of directions, generate right at the start of simulation. Each particle moves through its own array (gets rid of this while)
        Direction = ThreadLocalRandom.current().nextInt(1, 5);
        //Here we use negative speed as we are moving char to the left
        //int howMany = 0;

        while (Direction == lastD1 || Direction == lastD2) {
            Direction = ThreadLocalRandom.current().nextInt(1, 5);
            //howMany+=1;
        }
        //System.out.println("Stuck in loop for: " + howMany + " iterations.");

        //1 is down
        if(Direction == 1) {
            moveY(-SPEED * deltaTime);
            lastD1 = 3;
        }

        //2 is right
        if(Direction == 2) {
            moveX(SPEED * deltaTime);
            lastD2 = 4;
        }

        //3 is up
        if(Direction == 3) {
            moveY(SPEED * deltaTime);
            lastD1 = 1;
        }

        //4 is left
        if(Direction == 4) {
            moveX(-SPEED * deltaTime);
            lastD2 = 2;
        }

        if (map.doesRectCollideWithMap((this.pos.x + (SPEED * deltaTime)), this.pos.y, 32,32) || map.doesRectCollideWithMap((this.pos.x + (-SPEED * deltaTime)), this.pos.y, 32,32) || map.doesRectCollideWithMap(this.pos.x, (this.pos.y + (SPEED * deltaTime)), 32,32) || map.doesRectCollideWithMap(this.pos.x, (this.pos.y + (-SPEED * deltaTime)), 32,32)){
            lastD1 = 0;
            lastD2 = 0;
        }
    }

    @Override
    public void render(SpriteBatch batch) {
        //Pretty sure I'm rendering spores twice?
        batch.draw(image, pos.x, pos.y, getWidth(), getHeight());
    }

    public Texture getImage(){return image;}
    public boolean checkBinding(float x, float y, EntityType type){
        return false;
    }


}
