package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

public class BacteriaRed extends BacteriaGeneral {

    static int redCount;

    static BacteriaInfo otherRed;


    public BacteriaRed(float x, float y, GameMap map) {
        super(x, y, EntityType.BACTERIARED, map);
        setID(redCount);
        redCount += 1;

        //THIS IS FOR TESTING
        image = new Texture("RedBacTemp.jpg");
        System.out.println("Current red count: ");
        System.out.println(redCount);

        //TESTING END

    }



    public static void setRedCount(int initialize) {
        redCount = initialize;
    }

    @Override
    public int getBacteriaCount() {
        return redCount;
    }

    @Override
    public EntityType getBacteriaType() {
        return this.type;
    }

    public static void getInfo(BacteriaInfo bacteriaUpdate){
        otherRed = bacteriaUpdate;
    }

}