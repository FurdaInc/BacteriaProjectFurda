package furda.inc.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import furda.inc.simBase;

public class DesktopLauncher {
	public static void main (String[] arg) {

		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();

		//config.width = 1280;
		//config.height = 720;
		config.width = LwjglApplicationConfiguration.getDesktopDisplayMode().width;
		config.height = LwjglApplicationConfiguration.getDesktopDisplayMode().height;

		// fullscreen
		config.fullscreen = true;
		// vSync
		//config.vSyncEnabled = true;

		new LwjglApplication(new simBase(), config);
	}
}
