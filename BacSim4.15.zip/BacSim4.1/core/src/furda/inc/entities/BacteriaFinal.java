package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;

public class BacteriaFinal extends Entity{
    Texture image;
    public static boolean finalSpawned;

    //Animation test
    private TextureRegion[] regions = new TextureRegion[7];
    private int roll;
    private int count;

    private int moveCount;
    private boolean moveNow;

    public BacteriaFinal(float x, float y, EntityType type, GameMap map) {
        super(x, y, EntityType.BACTERIAFINAL, map);
        roll = 0;
        count = 0;
        moveCount = 0;
        moveNow = false;
        if(type == EntityType.BACTERIABLUE){
            image = new Texture("blueFinalTemp.jpg");
        }
        if(type == EntityType.BACTERIARED){
            image = new Texture("RedTransformation.png");
            regions[0] = new TextureRegion(image, 0, 0, 504,126);
            regions[1] = new TextureRegion(image, 504, 0, 504,126);
            regions[2] = new TextureRegion(image, 1008, 0, 504,126);
            regions[3] = new TextureRegion(image, 0, 126, 504,126);
            regions[4] = new TextureRegion(image, 504, 126, 504,126);
            regions[5] = new TextureRegion(image, 1008, 126, 504,126);
            regions[6] = new TextureRegion(image, 0, 252, 504,126);

        }
        setRemovable(false);
    }

    @Override
    public void update(float deltaTime, float gravity) {
        if(moveNow)
            moveY((getSpeed()*deltaTime));
    }

    @Override
    public void render(SpriteBatch batch) {

        if (roll == 7){
            roll = 0;
            moveCount+=1;
        }
        /*for(int i = 0; i <regions.length; i++){
            batch.draw(regions[i], pos.x, pos.y, getWidth(), getHeight());
        }*/
        batch.draw(regions[roll], pos.x, pos.y, getWidth(), getHeight());
        count +=1;
        if (count == 10) {
            roll += 1;
            count = 0;
        }
        if(moveCount == 5){
            moveNow = true;
            //CHANGE IMAGE HERE SO IT STOPS ANIMATION!!!
        }
        //Here is replication (or maybe original?)

    }

    @Override
    public boolean checkBinding(float x, float y, EntityType type) {
        return false;
    }
}
