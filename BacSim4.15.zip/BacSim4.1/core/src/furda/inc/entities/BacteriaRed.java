package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import furda.inc.world.GameMap;

public class BacteriaRed extends BacteriaGeneral {

    static int redCount;

    static BacteriaInfo otherRed;
    static BacteriaInfo competingBlue;
    static boolean redComplete;

    private boolean spawnedEnzyme;

    //Animation test
    private TextureRegion[] regions = new TextureRegion[5];
    private int roll;
    private int count;


    public BacteriaRed(float x, float y, GameMap map) {
        super(x, y, EntityType.BACTERIARED, map);
        redComplete = false;
        spawnedEnzyme = false;

        setID(redCount);
        redCount += 1;

        //THIS IS FOR TESTING
        //image = new Texture("RedBacTemp.jpg");
        System.out.println("Current red count: ");
        System.out.println(redCount);

        //TESTING END

        //Animation Testing
        image = new Texture("RZeroSpore.png");
        regions[0] = new TextureRegion(image, 0, 0, 126,126);
        regions[1] = new TextureRegion(image, 126, 0, 126,126);
        regions[2] = new TextureRegion(image, 252, 0, 126,126);
        regions[3] = new TextureRegion(image, 0, 126, 126,126);
        regions[4] = new TextureRegion(image, 126, 126, 126,126);
        roll = 0;
        count = 0;

    }

    @Override
    public void update(float deltaTime, float gravity) {
        super.update(deltaTime, gravity);
        //System.out.println(getID() + " Currently has: " + getSporeCount());
        if(getRedComplete()){
            if(Math.floor(getY())>((map.getHeight()*16)/2)){
                moveY(-getSpeed()*deltaTime);
                //System.out.println("My y is: " + getY());
                //System.out.println("Moving too: " + (map.getHeight()*16)/2);
            }
            else if(Math.ceil(getY())<((map.getHeight()*16)/2)){
                moveY(getSpeed()*deltaTime);
                //System.out.println("My y is: " + getY());
                //System.out.println("Moving too: " + (map.getHeight()*16)/2);
            }else{
                //System.out.println("CHUR");
                setInPlaceY();
            }
            if(Math.floor(getX()) > (((map.getWidth())*16)/6)*(getID()+1)){
                moveX(-getSpeed()*deltaTime);
            }
            else if(Math.ceil(getX()) < (((map.getWidth())*16)/6)*(getID()+1)){
                moveX(getSpeed()*deltaTime);
            }else{
                //System.out.println("Skeet skeet");
                setInPlaceX();
            }

        }

        for (BacteriaGeneral red : otherRed.getBacteriaArray()) {
            if (red == null) {
                //This bacteria has not been spawned yet.
                //System.out.println("Ok this will work");
                continue;
            } else if (red.getID() == this.getID()) {
                //This red bacteria is myself, no interactions with self (or own spores) is needed.

                continue;
                //System.out.println("Hey that's me!" + blue.getID() + " " + this.getID());
                //System.out.println(blue.getPos().x);
                //System.out.println(this.getPos().x);
            } else {
                //Check through the spores of this bacteria to see if any are touching me
                //System.out.println("That ain't me." + blue.getID() + " " + this.getID());
                for (Spore bindableSpore : red.getMyspores()) {
                    if ((bindableSpore.pos.x >= this.pos.x && bindableSpore.pos.x <= this.posR.x) && (bindableSpore.pos.y >= this.pos.y && bindableSpore.pos.y <= this.posR.y)) {
                        if (checkBinding(bindableSpore.pos.x, bindableSpore.pos.y, EntityType.SPORE)) {

                            if (otherRed.getBacteriaToAlter() == null) {

                                otherRed.setTempSpore(bindableSpore);
                                otherRed.setBacteriaToAlter(red);
                            }
                        }
                    }
                }
            }
        }

        if(competingBlue != null && !spawnedEnzyme) {
            for (BacteriaGeneral blue : competingBlue.getBacteriaArray()) {
                if (blue == null) {
                    //This bacteria has not been spawned yet.
                    //System.out.println("Ok this will work");
                    continue;
                } else {
                    //Check through the spores of this bacteria to see if any are touching me
                    //System.out.println("That ain't me." + blue.getID() + " " + this.getID());
                    for (Spore bindableSpore : blue.getMyspores()) {
                        if ((bindableSpore.pos.x >= this.pos.x && bindableSpore.pos.x <= this.posR.x) && (bindableSpore.pos.y >= this.pos.y && bindableSpore.pos.y <= this.posR.y)) {
                            if (checkBinding(bindableSpore.pos.x, bindableSpore.pos.y, EntityType.REDENZYME)) {

                                if (competingBlue.getBacteriaToAlter() == null) {

                                    competingBlue.setTempSpore(bindableSpore);
                                    competingBlue.setBacteriaToAlter(blue);
                                    System.out.println("SCHNEL");
                                }
                            }
                        }
                    }

                }
            }
        }

        if(competingBlue != null) {
            if (competingBlue.getBacteriaToAlter() != null) {
                competingBlue.getBacteriaToAlter().getMyspores().remove(competingBlue.getTempSpore());
                competingBlue.setBacteriaToAlter(null);
                competingBlue.setTempSpore(null);
                map.triggerSpawn(this);
                spawnedEnzyme = true;
            }
        }


        if(otherRed.getBacteriaToAlter() != null){

            otherRed.getBacteriaToAlter().getMyspores().remove(otherRed.getTempSpore());
            otherRed.setBacteriaToAlter(null);
            otherRed.setTempSpore(null);
            //Spawns too many spores. Needs to be 4, (5 is good for testing)
            if (this.getSporeCount() < 5) {
                this.getMyspores().add(new Spore(this.getX(), this.getY(), EntityType.SPORE, map, this));
                this.setSporeCount(this.getSporeCount() + 1);
            }
        }



    }

    @Override
    public void render(SpriteBatch batch) {

        if (roll == 5){
            roll = 0;
        }
        /*for(int i = 0; i <regions.length; i++){
            batch.draw(regions[i], pos.x, pos.y, getWidth(), getHeight());
        }*/
        batch.draw(regions[roll], pos.x, pos.y, getWidth(), getHeight());
        super.render(batch);
        count +=1;
        if (count == 10) {
            roll += 1;
            count = 0;
        }
        //Here is replication (or maybe original?)

    }





    public static void setRedCount(int initialize) {
        redCount = initialize;
    }

    public static boolean getRedComplete(){
        return redComplete;
    }

    public static void setRedComplete(){
        redComplete = true;
    }

    @Override
    public int getBacteriaCount() {
        return redCount;
    }

    @Override
    public EntityType getBacteriaType() {
        return this.type;
    }

    @Override
    public void checkForm() {
        if(checkBottomLeft()){
            if(checkBottomRight()){
                if(checkTopLeft()){
                    if(checkTopRight()){
                        //ALL POINTS BOUND
                        if(spawnedEnzyme){

                        }
                        else{
                            image = new Texture("Karsa.jpg");
                            regions[0] = new TextureRegion(image, 0, 0, 126,126);
                            regions[1] = new TextureRegion(image, 126, 0, 126,126);
                            regions[2] = new TextureRegion(image, 252, 0, 126,126);
                            regions[3] = new TextureRegion(image, 0, 126, 126,126);
                            regions[4] = new TextureRegion(image, 126, 126, 126,126);
                            return;
                        }
                    }
                    else{
                        //Bottom Left, Bottom Right and Top Left
                        if(spawnedEnzyme){

                        }
                        else{
                            image = new Texture("RBLBRTL.png");
                            regions[0] = new TextureRegion(image, 0, 0, 126,126);
                            regions[1] = new TextureRegion(image, 126, 0, 126,126);
                            regions[2] = new TextureRegion(image, 252, 0, 126,126);
                            regions[3] = new TextureRegion(image, 0, 126, 126,126);
                            regions[4] = new TextureRegion(image, 126, 126, 126,126);
                            return;
                        }
                    }
                }
                else if(checkTopRight()){
                    //Bottom Left, Bottom Right and Top Right
                    if(spawnedEnzyme){

                    }
                    else{
                        image = new Texture("RBLBRTR.png");
                        regions[0] = new TextureRegion(image, 0, 0, 126,126);
                        regions[1] = new TextureRegion(image, 126, 0, 126,126);
                        regions[2] = new TextureRegion(image, 252, 0, 126,126);
                        regions[3] = new TextureRegion(image, 0, 126, 126,126);
                        regions[4] = new TextureRegion(image, 126, 126, 126,126);
                        return;
                    }
                }
                else{
                    //Bottom Left AND Bottom Right
                    if(spawnedEnzyme){

                    }
                    else{
                        image = new Texture("RBLBR.png");
                        regions[0] = new TextureRegion(image, 0, 0, 126,126);
                        regions[1] = new TextureRegion(image, 126, 0, 126,126);
                        regions[2] = new TextureRegion(image, 252, 0, 126,126);
                        regions[3] = new TextureRegion(image, 0, 126, 126,126);
                        regions[4] = new TextureRegion(image, 126, 126, 126,126);
                        return;
                    }
                }
            }
            else if(checkTopLeft()){
                if(checkTopRight()){
                    //Bottom Left, Top Left and Top Right
                    if(spawnedEnzyme){

                    }
                    else{
                        image = new Texture("Karsa.jpg");
                        regions[0] = new TextureRegion(image, 0, 0, 126,126);
                        regions[1] = new TextureRegion(image, 126, 0, 126,126);
                        regions[2] = new TextureRegion(image, 252, 0, 126,126);
                        regions[3] = new TextureRegion(image, 0, 126, 126,126);
                        regions[4] = new TextureRegion(image, 126, 126, 126,126);
                        return;
                    }
                }
                else{
                    //Bottom Left and Top Left
                    if(spawnedEnzyme){

                    }
                    else{
                        image = new Texture("RBLTL.png");
                        regions[0] = new TextureRegion(image, 0, 0, 126,126);
                        regions[1] = new TextureRegion(image, 126, 0, 126,126);
                        regions[2] = new TextureRegion(image, 252, 0, 126,126);
                        regions[3] = new TextureRegion(image, 0, 126, 126,126);
                        regions[4] = new TextureRegion(image, 126, 126, 126,126);
                        return;
                    }
                }
            }
            else if(checkTopRight()){
                //Bottom Left and Top Right
                if(spawnedEnzyme){

                }
                else{
                    image = new Texture("RBLTR.png");
                    regions[0] = new TextureRegion(image, 0, 0, 126,126);
                    regions[1] = new TextureRegion(image, 126, 0, 126,126);
                    regions[2] = new TextureRegion(image, 252, 0, 126,126);
                    regions[3] = new TextureRegion(image, 0, 126, 126,126);
                    regions[4] = new TextureRegion(image, 126, 126, 126,126);
                    return;
                }
            }
            else{
                //Bottom Left
                if(spawnedEnzyme){

                }
                else{
                    image = new Texture("RBL.png");
                    regions[0] = new TextureRegion(image, 0, 0, 126,126);
                    regions[1] = new TextureRegion(image, 126, 0, 126,126);
                    regions[2] = new TextureRegion(image, 252, 0, 126,126);
                    regions[3] = new TextureRegion(image, 0, 126, 126,126);
                    regions[4] = new TextureRegion(image, 126, 126, 126,126);
                    return;
                }
            }
        }
        else if (checkBottomRight()){
            if(checkTopLeft()){
                if(checkTopRight()){
                    //Bottom Right, Top Left and Top Right
                    if(spawnedEnzyme){

                    }
                    else{
                        image = new Texture("Karsa.jpg");
                        regions[0] = new TextureRegion(image, 0, 0, 126,126);
                        regions[1] = new TextureRegion(image, 126, 0, 126,126);
                        regions[2] = new TextureRegion(image, 252, 0, 126,126);
                        regions[3] = new TextureRegion(image, 0, 126, 126,126);
                        regions[4] = new TextureRegion(image, 126, 126, 126,126);
                        return;
                    }
                }
                else{
                    //Bottom Right and Top Left
                    if(spawnedEnzyme){

                    }
                    else{
                        image = new Texture("RBRTL.png");
                        regions[0] = new TextureRegion(image, 0, 0, 126,126);
                        regions[1] = new TextureRegion(image, 126, 0, 126,126);
                        regions[2] = new TextureRegion(image, 252, 0, 126,126);
                        regions[3] = new TextureRegion(image, 0, 126, 126,126);
                        regions[4] = new TextureRegion(image, 126, 126, 126,126);
                        return;
                    }
                }
            }
            else if(checkTopRight()){
                //Bottom Right and Top Right
                if(spawnedEnzyme){

                }
                else{
                    image = new Texture("Karsa.jpg");
                    regions[0] = new TextureRegion(image, 0, 0, 126,126);
                    regions[1] = new TextureRegion(image, 126, 0, 126,126);
                    regions[2] = new TextureRegion(image, 252, 0, 126,126);
                    regions[3] = new TextureRegion(image, 0, 126, 126,126);
                    regions[4] = new TextureRegion(image, 126, 126, 126,126);
                    return;
                }
            }
            else{
                //Bottom Right
                if(spawnedEnzyme){

                }
                else{
                    image = new Texture("RBR.png");
                    regions[0] = new TextureRegion(image, 0, 0, 126,126);
                    regions[1] = new TextureRegion(image, 126, 0, 126,126);
                    regions[2] = new TextureRegion(image, 252, 0, 126,126);
                    regions[3] = new TextureRegion(image, 0, 126, 126,126);
                    regions[4] = new TextureRegion(image, 126, 126, 126,126);
                    return;
                }
            }
        }
        else if (checkTopLeft()){
            if(checkTopRight()){
                //Top Left and Top Right
                if(spawnedEnzyme){

                }
                else{
                    image = new Texture("RTLTR.png");
                    regions[0] = new TextureRegion(image, 0, 0, 126,126);
                    regions[1] = new TextureRegion(image, 126, 0, 126,126);
                    regions[2] = new TextureRegion(image, 252, 0, 126,126);
                    regions[3] = new TextureRegion(image, 0, 126, 126,126);
                    regions[4] = new TextureRegion(image, 126, 126, 126,126);
                    return;
                }
            }
            else{
                //Top Left
                if(spawnedEnzyme){

                }
                else{
                    image = new Texture("RTL.png");
                    regions[0] = new TextureRegion(image, 0, 0, 126,126);
                    regions[1] = new TextureRegion(image, 126, 0, 126,126);
                    regions[2] = new TextureRegion(image, 252, 0, 126,126);
                    regions[3] = new TextureRegion(image, 0, 126, 126,126);
                    regions[4] = new TextureRegion(image, 126, 126, 126,126);
                    return;
                }
            }
        }
        else if (checkTopRight()){
            //Top Right
            if(spawnedEnzyme){

            }
            else{
                image = new Texture("RTR.png");
                regions[0] = new TextureRegion(image, 0, 0, 126,126);
                regions[1] = new TextureRegion(image, 126, 0, 126,126);
                regions[2] = new TextureRegion(image, 252, 0, 126,126);
                regions[3] = new TextureRegion(image, 0, 126, 126,126);
                regions[4] = new TextureRegion(image, 126, 126, 126,126);
                return;
            }
        }
        else{
            //No bindings as yet.
            if(spawnedEnzyme){

            }
            else{
                return;
            }
        }
    }

    public static void getInfo(BacteriaInfo bacteriaUpdate){
        otherRed = bacteriaUpdate;
    }

    public static void getCompetingInfo(BacteriaInfo bacteriaUpdate){
        competingBlue = bacteriaUpdate;
    }

}