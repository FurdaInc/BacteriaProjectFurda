package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

public class BacteriaBlue extends BacteriaGeneral {

    static int blueCount;


    public BacteriaBlue(float x, float y, GameMap map) {
        super(x, y, EntityType.BACTERIABLUE, map);
        setID(blueCount);
        blueCount += 1;

    }

    @Override
    public void render(SpriteBatch batch) {

    }

    public static void setBlueCount(int initialize){
        blueCount = initialize;
    }

    @Override
    public int getBacteriaCount() {
        return blueCount;
    }

    @Override
    public EntityType getBacteriaType() {
        return this.type;
    }
}
