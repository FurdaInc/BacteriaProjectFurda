package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

public abstract class Particles extends Entity {

    protected Texture image;

    protected int lastD1, lastD2;
    protected int direction;



    public Particles(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        lastD1 = 0;
        lastD2 = 0;
    }

    @Override
    public void update(float deltaTime, float gravity){

    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(image, pos.x, pos.y, getWidth(), getHeight());
    }
}
