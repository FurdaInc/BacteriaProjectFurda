package furda.inc.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

public class BacteriaRed extends BacteriaGeneral {

    static int redCount;

    public BacteriaRed(float x, float y, GameMap map) {
        super(x, y, EntityType.BACTERIARED, map);
        setID(redCount);
        redCount += 1;
    }

    @Override
    public void render(SpriteBatch batch) {

    }

    public static void setRedCount(int initialize) {
        redCount = initialize;
    }

    @Override
    public int getBacteriaCount() {
        return redCount;
    }

    @Override
    public EntityType getBacteriaType() {
        return this.type;
    }
}