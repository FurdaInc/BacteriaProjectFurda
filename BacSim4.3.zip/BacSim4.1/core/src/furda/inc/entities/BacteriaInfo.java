package furda.inc.entities;

public class BacteriaInfo {
    private boolean isBound;
    private int bacteriaID;
    private BacteriaGeneral[] bacteriaArray;
    private BacteriaGeneral bacteriaToAlter;
    private BacteriaGeneral bacteriaToRemove;
    private Spore tempSpore;
    private int bacteriaCount;


    public BacteriaInfo(EntityType e){
        isBound = false;
        if (e == EntityType.BACTERIABLUE){
            bacteriaArray = new BacteriaBlue[5];
        }else{
            bacteriaArray = new BacteriaRed[5];
        }
        bacteriaCount = 0;
    }

    public BacteriaGeneral[] getBacteriaArray(){
        return bacteriaArray;
    }

    public BacteriaGeneral getBacteriaByID(int id){
        if (id<5) {
            return bacteriaArray[id];
        }else{
            return null;
        }
    }

    public void setBacteriaArray(int ID, BacteriaGeneral set){
        bacteriaArray[ID] = set;
    }

    public BacteriaGeneral getBacteriaToAlter(){
        return bacteriaToAlter;
    }

    public void setBacteriaToAlter(BacteriaGeneral set){
        bacteriaToAlter = set;
    }

    public BacteriaGeneral getBacteriaToRemove(){
        return bacteriaToRemove;
    }

    public void setBacteriaToRemove(BacteriaGeneral set){
        bacteriaToRemove = set;
    }

    public Spore getTempSpore(){
        return tempSpore;
    }

    public void setTempSpore(Spore set){
        tempSpore = set;
    }

    public int getBacteriaID(){
        return bacteriaID;
    }

    public void setBacteriaID(BacteriaGeneral e){
        bacteriaID = e.getID();
    }

    public int getBacteriaCount(){return bacteriaCount;}
    public void incrementBacteriaCount(){bacteriaCount = bacteriaCount+1;}

}
