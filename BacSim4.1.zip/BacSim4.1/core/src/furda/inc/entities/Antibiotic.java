package furda.inc.entities;

import furda.inc.world.GameMap;

public class Antibiotic extends Particles {
    public Antibiotic(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
    }
}
