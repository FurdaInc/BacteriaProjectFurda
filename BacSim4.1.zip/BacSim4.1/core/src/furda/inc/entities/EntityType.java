package furda.inc.entities;

public enum EntityType {


    //id name, width (here 14 as bricks are 16 wide, being 14 the player can slip through)
    //Height - player is 2 bricks high
    //The weight is going to be an assigned value for gravity. This affects fall speed

    BACTERIABLUE("blueBacteria", 128, 64),
    BACTERIARED("redBacteria", 128,64),
    SPORE("spore",16,16),
    GARLIC("garlic",16,16),
    WBC("whiteBloodCell",16,16),
    ANTIBIOTIC("antibiotics",16,16),
    BUTTON("button",128,64);


    private String id;
    private int width, height;
    private float weight;

    public String getId() {
        return id;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public float getWeight() {
        return weight;
    }

    EntityType(String id, int width, int height) {
        this.id = id;
        this.width = width;
        this.height = height;
    }


}
