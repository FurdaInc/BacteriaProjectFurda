package furda.inc.world;

import java.util.HashMap;

public enum TileType {


    FEATURE14( 24, false, "Feature14");

    public static final int TILE_SIZE = 16;

    private int id;
    private boolean collidable;
    private String name;
    private float damage;

    private TileType(int id, boolean collidable, String name){

        this(id, collidable, name, 0);

    }

    private TileType(int id, boolean collidable, String name, float damage){

        this.id = id;
        this.collidable = collidable;
        this.name = name;
        this.damage = damage;

    }

    public boolean isCollidable() {
        return collidable;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public float getDamage() {
        return damage;
    }

    private static HashMap<Integer, TileType> tileMap;


    //The below sets up a dictionary containing each of the tiles we have made
    //It has a key and a value (value, key)
    static{
        tileMap = new HashMap<Integer, TileType>();
        for(TileType tileType : TileType.values()){
            tileMap.put(tileType.getId(), tileType);
        }
    }

    //This returns what the tile type is when an id is entered
    public static TileType getTileTypeById (int id){
        return tileMap.get(id);
    }

}
