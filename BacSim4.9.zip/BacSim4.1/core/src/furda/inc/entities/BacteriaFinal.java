package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

public class BacteriaFinal extends Entity{
    Texture image;
    public static boolean finalSpawned;

    public BacteriaFinal(float x, float y, EntityType type, GameMap map) {
        super(x, y, EntityType.BACTERIAFINAL, map);
        if(type == EntityType.BACTERIABLUE){
            image = new Texture("RedBacTemp.jpg");
        }
        setRemovable(false);
    }

    @Override
    public void update(float deltaTime, float gravity) {
        moveY((getSpeed()*deltaTime));
    }

    @Override
    public void render(SpriteBatch batch) {
        batch.draw(image, pos.x, pos.y, getWidth(), getHeight());
    }

    @Override
    public boolean checkBinding(float x, float y, EntityType type) {
        return false;
    }
}
