package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import furda.inc.world.GameMap;

public class Antibiotic extends Particles {
    public Antibiotic(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        image = new Texture("anti-biotic.png");
    }
}
