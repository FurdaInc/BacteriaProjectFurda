package furda.inc.entities;

public class BacteriaInfo {
    private boolean isBound;
    private int bacteriaID;
    private BacteriaGeneral[] bacteriaArray;
    private BacteriaGeneral bacteriaToAlter;
    private BacteriaGeneral bacteriaToRemove;
    private Spore tempSpore;
    private int bacteriaCount;

    //For binding of blue spores on red bacteria
    private Spore competingTempSpore;


    public BacteriaInfo(EntityType e){
        isBound = false;
        if (e == EntityType.BACTERIABLUE){
            bacteriaArray = new BacteriaBlue[4];
        }else{
            bacteriaArray = new BacteriaRed[4];
        }
        bacteriaCount = 0;
        tempSpore = null;
        bacteriaToAlter = null;
        bacteriaToRemove = null;
    }

    public BacteriaGeneral[] getBacteriaArray(){
        return bacteriaArray;
    }

    public BacteriaGeneral getBacteriaByID(int id){
        if (id<5) {
            try {
                return bacteriaArray[id];
            }finally{
                return null;
            }
        }else{
            return null;
        }
    }

    public void setBacteriaArray(int ID, BacteriaGeneral set){
        bacteriaArray[ID] = set;

        /*//FOR TESTING
        System.out.println("This bac ID is: ");
        System.out.println(ID);*/

    }

    public BacteriaGeneral getBacteriaToAlter(){
        return bacteriaToAlter;
    }

    public void setBacteriaToAlter(BacteriaGeneral set){
        bacteriaToAlter = set;
    }

    public BacteriaGeneral getBacteriaToRemove(){
        return bacteriaToRemove;
    }

    public void setBacteriaToRemove(BacteriaGeneral set){
        bacteriaToRemove = set;
    }

    public Spore getTempSpore(){
        return tempSpore;
    }

    public void setTempSpore(Spore set){
        tempSpore = set;
    }
    public void setTempCompetingSpore(Spore set){competingTempSpore = set;}

    public int getBacteriaID(){
        return bacteriaID;
    }

    public void setBacteriaID(BacteriaGeneral e){
        bacteriaID = e.getID();
    }

    public int getBacteriaCount(){return bacteriaCount;}
    public void incrementBacteriaCount(){bacteriaCount = bacteriaCount+1;}


}
