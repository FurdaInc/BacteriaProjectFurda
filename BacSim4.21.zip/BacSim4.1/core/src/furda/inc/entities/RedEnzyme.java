package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import furda.inc.world.GameMap;

public class RedEnzyme extends Particles{
    public RedEnzyme(EntityType type, GameMap map, BacteriaRed parent) {
        super(parent.getX(), parent.getY(), type, map);
        image = new Texture("RedKillerSpore.png");
    }

    @Override
    public void update(float deltaTime, float gravity) {
        super.update(deltaTime, gravity);
    }

}
