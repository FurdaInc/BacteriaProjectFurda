package furda.inc.entities;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import furda.inc.world.GameMap;

public class Garlic extends Particles {
    public Garlic(float x, float y, EntityType type, GameMap map) {
        super(x, y, type, map);
        image = new Texture("Garlic.png");
    }


}
