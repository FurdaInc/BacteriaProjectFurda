<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.4" name="Walls" tilewidth="16" tileheight="16" tilecount="676" columns="26">
 <image source="../BacSim4.1/Tile2.png" width="417" height="417"/>
</tileset>
